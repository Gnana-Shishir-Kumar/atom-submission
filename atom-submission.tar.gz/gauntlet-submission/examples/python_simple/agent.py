#!/usr/bin/env python3
"""Simple Agent Gauntlet competitor agent.

This is a minimal example showing how to connect to Agent Gauntlet from any Python code.
It uses:
- HTTP client for Agent Gauntlet coordination (REST API)
- MCP client for challenge tools
- OpenAI SDK for LLM calls via the proxy

Usage:
    cd examples/python_simple
    python agent.py

This example loads `.env` from the repository root automatically.
"""

import asyncio
import base64
import binascii
import json
import os
import re
import subprocess
import sys
import time
import zlib
from concurrent.futures import ThreadPoolExecutor, wait
from pathlib import Path
from urllib.error import HTTPError
from urllib.parse import quote
from urllib.request import Request, urlopen

from dotenv import load_dotenv

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path: 
    sys.path.insert(0, str(REPO_ROOT))

load_dotenv(REPO_ROOT / ".env")

from arena_clients.config import agent_id_problem
from arena_clients import (
    build_image_tool_arguments,
    HttpArenaClient,
    McpArenaClient,
    McpArenaError,
    ensure_connected,
    get_api_base,
    get_arena_api_key,
    get_mcp_url,
    get_proxy_host,
    monitor_session,
)
from arena_clients.display import (
    ReasoningTicker,
    challenge_record,
    print_challenge,
    save_run_record,
    summary_lines,
)
from arena_clients.outputs import missing_tools_note, save_submitted_image, submission_summary_lines
from arena_clients.proxy_headers import build_proxy_headers, resolve_usage_scope
from base_strategy import ChallengeContext
from model_selector import (
    ModelSelectionError,
    fetch_available_models,
    require_explicit_model,
)
import my_strategy as _strategy_module
from my_strategy import MyStrategy

# ATOM's answer gates and ReAct parser live in my_strategy; a strategy module
# without them keeps the stock behaviour (no format gate, verify or ReAct).
format_ok = getattr(_strategy_module, "format_ok", lambda answer, rules: bool(str(answer or "").strip()))
normalize_answer = getattr(_strategy_module, "normalize_answer", lambda answer, rules: str(answer or "").strip())
parse_verify_response = getattr(_strategy_module, "parse_verify_response", lambda raw: (True, ""))
parse_react_reply = getattr(_strategy_module, "parse_react_reply", lambda raw: ("none", None))
react_call_signature = getattr(
    _strategy_module,
    "react_call_signature",
    lambda name, arguments: (str(name), json.dumps(arguments or {}, sort_keys=True, default=str)),
)

# Use OpenAI SDK for LLM calls through the proxy.
try:
    from openai import OpenAI

    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False


BLANK_PNG_DATA_URI = (
    "data:image/png;base64,"
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO7/"
    "S7sAAAAASUVORK5CYII="
)


class _QueuedNotes:
    """HttpArenaClient wrapper whose thoughts and drafts never block the solve.

    Speed is scored from battle start, and each thought is a remote round
    trip. One worker keeps them in order; flush() before submit makes sure
    every thought is counted.
    """

    def __init__(self, client: HttpArenaClient):
        self._client = client
        self._pool = ThreadPoolExecutor(max_workers=1)
        self._pending: list = []

    def __getattr__(self, name: str):
        return getattr(self._client, name)

    def _queue(self, fn, *args, **kwargs) -> None:
        def run() -> None:
            try:
                fn(*args, **kwargs)
            except Exception as exc:
                print(f"   (note not sent: {type(exc).__name__})")

        self._pending.append(self._pool.submit(run))

    def broadcast_thought(self, *args, **kwargs) -> None:
        self._queue(self._client.broadcast_thought, *args, **kwargs)

    def save_draft(self, *args, **kwargs) -> None:
        self._queue(self._client.save_draft, *args, **kwargs)

    def flush(self, timeout_s: float = 5.0) -> None:
        """Wait for the first thought only: that avoids the no-thought penalty,
        and waiting on a backlog of streamed reasoning would only delay submit."""
        if self._pending:
            wait(self._pending[:1], timeout=timeout_s)


async def _solve_within(budget_s: float, make_coro, fallback):
    """Run a (blocking) solve coroutine in a worker thread, at most budget_s.

    solve_challenge makes synchronous proxy calls, so asyncio.wait_for alone
    could not interrupt it. On timeout the caller gets ``fallback`` and
    submits a safe answer instead of missing the deadline.
    """
    try:
        return await asyncio.wait_for(
            asyncio.to_thread(asyncio.run, make_coro()),
            timeout=max(1.0, budget_s),
        )
    except asyncio.TimeoutError:
        print(f"   ⏱️  Solve exceeded its {budget_s:.0f}s budget; using the strategy fallback.")
        return fallback
    except Exception as exc:
        # Proxy errors (model down, 429, 5xx) mark the result so the caller
        # can fail over to the next ranked model instead of crashing.
        print(f"   ⚠️  Solve failed ({type(exc).__name__}: {str(exc)[:160]})")
        answer, raw, model, usage, ttft, total = fallback
        return answer, raw, model, {**usage, "finish_reason": "error"}, ttft, total


# Proxy health probe: a dead or rate-limited alias found before the challenge
# timer starts costs nothing; found at solve time it costs the puzzle.
PROBE_TIMEOUT_S = 10.0
# A probe only checks that the alias answers at all (finish "length" counts
# as healthy), so it needs no answer budget; keep its token cost minimal.
PROBE_MAX_TOKENS = 16


def _probe_models(llm_client, models: list[str]) -> list[str]:
    """Return the subset of ``models`` that answer a one-line request."""

    def probe(model: str) -> bool:
        try:
            llm_client.with_options(timeout=PROBE_TIMEOUT_S, max_retries=0).chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": "Reply with: OK"}],
                max_tokens=PROBE_MAX_TOKENS,
                temperature=0.0,
            )
            return True
        except Exception as exc:
            print(f"   ⚠️  Model probe failed for {model}: {type(exc).__name__}")
            return False

    if not models:
        return []
    with ThreadPoolExecutor(max_workers=len(models)) as pool:
        healthy = list(pool.map(probe, models))
    return [model for model, ok in zip(models, healthy) if ok]


def _plan_image_tool_sequence(
    strategy: MyStrategy,
    ctx: ChallengeContext,
    available_tools: list[str],
) -> list[str]:
    """Expand an analysis-first choice into a usable image-output plan."""
    selected_tool = strategy.plan_image_tool(ctx, available_tools)
    if not selected_tool:
        return []
    sequence = [selected_tool]
    if selected_tool != "image_analyze":
        return sequence
    if ctx.image_url and "image_edit" in available_tools:
        sequence.append("image_edit")
    elif "image_generate" in available_tools:
        sequence.append("image_generate")
    return sequence


def _append_run_log(agent_id: str, record: dict) -> None:
    """Best effort: append one line per run to outputs/<agent_id>-runs.jsonl.

    run.json is overwritten every run; this keeps history for
    ``atom_bench/eval.py --practice``, tagged with the commit that ran.
    """
    try:
        commit = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"], cwd=REPO_ROOT, capture_output=True, text=True, timeout=5
        ).stdout.strip() or None
    except Exception:
        commit = None
    try:
        challenge = record.get("challenge") or {}
        result = record.get("result") or {}
        line = {
            "when": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "commit": commit,
            "puzzle_id": challenge.get("puzzle_id"),
            "challenge_type": challenge.get("challenge_type"),
            "difficulty": challenge.get("difficulty"),
            "model": record.get("model"),
            "answer": record.get("answer"),
            "accepted": result.get("accepted"),
            "score": {k: v for k, v in (result.get("score") or {}).items() if k != "output_image_uri"},
        }
        safe_id = re.sub(r"[^A-Za-z0-9_-]", "_", str(agent_id))[:64] or "agent"
        out_dir = REPO_ROOT / "outputs"
        out_dir.mkdir(exist_ok=True)
        with open(out_dir / f"{safe_id}-runs.jsonl", "a", encoding="utf-8") as handle:
            handle.write(json.dumps(line, default=str) + "\n")
    except Exception:
        pass


def extract_answer(raw_response: str) -> str:
    """Extract the answer line from the LLM response."""
    cleaned = re.sub(r"<think>.*?(?:</think>|$)", "", raw_response, flags=re.DOTALL).strip()
    cleaned = re.sub(r"<toolcall\b[^>]*>.*?(?:</toolcall>|$)", "", cleaned, flags=re.DOTALL | re.IGNORECASE)

    # Accept either "ANSWER:" or "Final answer:" on its own line. Like the
    # Game Arena parser, the last match wins (worked solutions may restate a
    # draft answer earlier) and markdown/LaTeX wrapping is stripped.
    for line in reversed(cleaned.splitlines()):
        line = re.sub(r"</?\w+>", "", line).replace("**", "").replace("__", "")
        match = re.match(
            r"^[\s>#*\-]*(?:answer|final answer)\s*:\s*(.+?)\s*$",
            line,
            flags=re.IGNORECASE,
        )
        if match:
            answer = match.group(1).strip()
            answer = re.sub(r"^\$*\\boxed\{(.*)\}\$*$", r"\1", answer)
            answer = re.sub(r"^\\text\{(.*)\}$", r"\1", answer).strip().strip("`\"'")
            if answer:
                return answer

    return ""


def _challenge_text_blob(
    challenge_type: str,
    description: str,
    rules: str,
    extra_context: str = "",
) -> str:
    return " ".join(
        [challenge_type or "", description or "", rules or "", extra_context or ""]
    ).lower()


def _required_runtime_tools(
    available_tool_names: list[str],
    *,
    challenge_type: str,
    description: str,
    rules: str,
    extra_context: str = "",
) -> list[str]:
    blob = _challenge_text_blob(challenge_type, description, rules, extra_context)
    required: list[str] = []
    for tool_name in available_tool_names:
        normalized = str(tool_name or "").strip()
        if not normalized:
            continue
        if normalized.lower() in blob:
            required.append(normalized)
    if challenge_type.strip().lower() in {"web-search", "market-research"}:
        for tool_name in available_tool_names:
            normalized = str(tool_name or "").strip()
            if "search" in normalized.lower() and normalized not in required:
                required.append(normalized)
    return required


def _best_search_query(description: str, rules: str, clues: list[str] | None) -> str:
    text = (description or "").strip()
    if text:
        return text
    if clues:
        for clue in clues:
            if isinstance(clue, str) and clue.strip():
                return clue.strip()
    return (rules or "").strip()


def _query_candidates(
    description: str,
    rules: str,
    clues: list[str] | None,
    extra_context: str = "",
) -> list[str]:
    candidates: list[str] = []
    primary = _best_search_query(description, rules, clues)
    if primary:
        candidates.append(primary)
    for clue in clues or []:
        if isinstance(clue, str) and clue.strip():
            candidates.append(clue.strip())
    if isinstance(rules, str) and rules.strip():
        split_parts = re.split(r"[.;\n]+", rules)
        for part in split_parts:
            part = part.strip()
            if 8 <= len(part) <= 220:
                candidates.append(part)
    for text in [description, rules, extra_context, *(clues or [])]:
        if not isinstance(text, str):
            continue
        for url in re.findall(r"https?://[^\s)>\"]+", text):
            cleaned = url.strip().rstrip(".,);")
            if cleaned:
                candidates.append(cleaned)
    deduped: list[str] = []
    seen: set[str] = set()
    for item in candidates:
        key = item.lower()
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped[:5]


def _tool_result_text(result: object) -> str:
    if result is None:
        return ""
    if isinstance(result, str):
        return result.strip()
    if isinstance(result, (int, float, bool)):
        return str(result)
    if isinstance(result, list):
        parts = [_tool_result_text(item) for item in result]
        return "\n".join(part for part in parts if part).strip()
    if isinstance(result, dict):
        cleaned: dict[str, object] = {}
        for key, value in result.items():
            key_lower = str(key).lower()
            if "image" in key_lower and isinstance(value, str) and len(value) > 256:
                continue
            cleaned[str(key)] = value
        try:
            return json.dumps(cleaned, ensure_ascii=False)
        except Exception:
            return str(cleaned)
    return str(result)


def _is_invalid_answer_candidate(value: str) -> bool:
    text = str(value or "").strip()
    if not text:
        return True
    lowered = text.lower()
    if lowered.startswith(("<toolcall", "toolcall", "<think", "reasoning:", "analysis:", "action:")):
        return True
    blocked_tokens = ("<toolcall", "</toolcall", '"tool_calls"', "function_call")
    return any(token in lowered for token in blocked_tokens)


def _derive_answer_from_evidence(
    *,
    llm_client,
    model_name: str,
    challenge_description: str,
    challenge_rules: str,
    evidence_lines: list[str],
    max_tokens: int = 8192,
) -> str:
    if not evidence_lines:
        return ""
    evidence_block = "\n".join(f"- {line}" for line in evidence_lines if line.strip())
    if not evidence_block:
        return ""
    try:
        response = llm_client.chat.completions.create(
            model=model_name,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "Use the provided tool evidence to answer the challenge. "
                        "Return only one final answer line that follows the challenge rules."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"Question: {challenge_description}\n"
                        f"Rules: {challenge_rules}\n\n"
                        f"Tool evidence:\n{evidence_block}\n\n"
                        "Return only the final answer line."
                    ),
                },
            ],
            max_tokens=max_tokens,
            temperature=0.0,
        )
    except Exception:
        return ""
    raw = (response.choices[0].message.content or "").strip()
    answer = extract_answer(raw)
    if answer:
        return answer
    first_line = raw.splitlines()[0].strip().strip("`\"'") if raw.strip() else ""
    return "" if _is_invalid_answer_candidate(first_line) else first_line


_SEARCH_QUERY_PARAMS = ("query", "q", "search_query", "text", "question", "search", "keywords")
# Search results are the evidence for research challenges; 2000 chars cut
# off the third result of a typical response.
_SEARCH_RESULT_CHARS = 6000


def _search_payloads(tool_def, agent_id: str, query: str) -> list[dict]:
    """Argument sets to try for one search call, schema-derived first."""
    props = (getattr(tool_def, "inputSchema", None) or {}).get("properties") or {}
    payloads = []
    param = next((p for p in _SEARCH_QUERY_PARAMS if p in props), "")
    if param:
        payload = {param: query}
        if "agent_id" in props:
            payload["agent_id"] = agent_id
        payloads.append(payload)
    for key in ("query", "search_query", "text"):
        payloads += [{"agent_id": agent_id, key: query}, {key: query}]
    return payloads


async def _search_calls(
    mcp_client: McpArenaClient, tool_name: str, queries: list[str], agent_id: str, tool_def=None
) -> list[str]:
    """Runs every query against one search tool concurrently; returns evidence lines."""

    async def one(query: str) -> str:
        for payload in _search_payloads(tool_def, agent_id, query):
            try:
                result = await mcp_client.call_tool(tool_name, payload)
            except Exception:
                continue
            rendered = _tool_result_text(result)
            return f"{tool_name}({json.dumps({'query': query})}): {rendered[:_SEARCH_RESULT_CHARS]}" if rendered else ""
        return ""

    lines = await asyncio.gather(*(one(query) for query in queries))
    return [line for line in lines if line]


def _follow_up_query(llm_client, model_name: str, strategy, ctx, results: list[str], timeout_s: float) -> str:
    """One planner call for a second search round; "" when none is needed."""
    prompt = strategy.follow_up_prompt(ctx, results)
    try:
        response = llm_client.chat.completions.create(
            model=model_name,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=2048,
            temperature=0.0,
            timeout=timeout_s,
        )
    except Exception as exc:
        print(f"   (follow-up search skipped: {type(exc).__name__})")
        return ""
    return strategy.parse_follow_up(response.choices[0].message.content or "")


async def _enforce_required_tool_calls(
    *,
    mcp_client: McpArenaClient,
    agent_id: str,
    challenge_type: str,
    description: str,
    rules: str,
    clues: list[str] | None,
    available_tool_names: list[str],
    http_client: HttpArenaClient,
    extra_context: str = "",
    declared_required: list[str] | None = None,
    search_queries: list[str] | None = None,
    tool_defs: list | None = None,
    payload: dict | None = None,
    succeeded: set[str] | None = None,
) -> list[str]:
    """Calls every tool the challenge requires; returns evidence lines.

    Tools that answered without an error are added to ``succeeded`` so the
    caller can retry the rest (a skipped required tool zeroes quality).
    """
    required_runtime_tools = _required_runtime_tools(
        available_tool_names,
        challenge_type=challenge_type,
        description=description,
        rules=rules,
        extra_context=extra_context,
    )
    # A strategy that plans queries wants search even on a "text" challenge.
    if search_queries:
        for tool_name in available_tool_names:
            if "search" in tool_name.lower() and tool_name not in required_runtime_tools:
                required_runtime_tools.append(tool_name)
    # The payload's required_tools list is authoritative: skipping one sets
    # quality to 0. The caller drops the ones the runtime already called.
    for tool_name in declared_required or []:
        if tool_name in available_tool_names and tool_name not in required_runtime_tools:
            required_runtime_tools.append(tool_name)
    if not required_runtime_tools:
        return []

    evidence_lines: list[str] = []
    queries = _query_candidates(description, rules, clues, extra_context)
    if not queries:
        queries = [""]
    defs_by_name = {str(getattr(t, "name", "")): t for t in tool_defs or []}
    pool: dict[str, list] = {}
    _collect_values(payload or {}, pool)
    for tool_name in required_runtime_tools:
        is_search_like = "search" in tool_name.lower()
        if is_search_like and search_queries:
            lines = await _search_calls(mcp_client, tool_name, search_queries, agent_id, defs_by_name.get(tool_name))
            evidence_lines += lines
            if lines and succeeded is not None:
                succeeded.add(tool_name)
            try:
                http_client.broadcast_thought(
                    agent_id, f"Required tool coverage: {tool_name} ({len(lines)}/{len(search_queries)})"
                )
            except Exception:
                pass
            continue
        target_calls = min(len(queries), 3) if is_search_like else 1
        calls_made = 0
        for query in queries[:target_calls]:
            # Schema-built arguments first: guessed shapes miss tools whose
            # required parameter is an id from the payload.
            schema_sets = (
                _explore_argument_sets(defs_by_name[tool_name], agent_id, pool, query)[:1]
                if tool_name in defs_by_name
                else []
            )
            payload_variants = [
                *schema_sets,
                {"agent_id": agent_id, "query": query},
                {"query": query},
                {"agent_id": agent_id, "search_query": query},
                {"search_query": query},
                {"agent_id": agent_id, "text": query},
                {"text": query},
                {"agent_id": agent_id, "url": query},
                {"url": query},
                {"agent_id": agent_id, "video_url": query},
                {"video_url": query},
                {"agent_id": agent_id},
                {},
            ]
            for payload in payload_variants:
                try:
                    result = await mcp_client.call_tool(tool_name, payload)
                except Exception:
                    continue
                if isinstance(result, dict) and result.get("error"):
                    continue
                rendered = _tool_result_text(result)
                if rendered:
                    evidence_lines.append(f"{tool_name}: {rendered[:2000]}")
                _collect_values(result, pool)
                calls_made += 1
                if succeeded is not None:
                    succeeded.add(tool_name)
                break
        status_note = (
            f"Required tool coverage: {tool_name} ({calls_made}/{target_calls})"
            if target_calls > 1
            else f"Required tool called: {tool_name}"
            if calls_made
            else f"Could not call required tool: {tool_name}"
        )
        try:
            http_client.broadcast_thought(agent_id, status_note)
        except Exception:
            pass
    return evidence_lines


# Hard-blocked always: submit/register/status/destructive/render paths.
_EXPLORE_HARD_BLOCK = re.compile(
    r"submit|regist|broadcast|thought|draft|delete|remove|reset|disconnect|status|image",
    re.I,
)
# Back-compat alias used by older call sites / tests.
_EXPLORE_SKIP = _EXPLORE_HARD_BLOCK
# Non-destructive state tools: allowed only when stateful_unlock_enabled.
_STATEFUL_UNLOCK_ALLOW = re.compile(
    r"(?:^|[._-])(?:unlock|open|set[_-]?key|decrypt|decode|activate|enable)(?:$|[._-])",
    re.I,
)
# Other write-ish names stay blocked even with the unlock gate on.
_EXPLORE_WRITEISH = re.compile(
    r"(?:^|[._-])(?:write|put|update|create|insert|destroy|drop|kill|send|post|patch)(?:$|[._-])",
    re.I,
)
_SECRET_PARAM_NAMES = (
    "key",
    "code",
    "password",
    "pin",
    "token",
    "secret",
    "passphrase",
    "cipher",
    "ciphertext",
)
# Already driven by the runtime itself.
_EXPLORE_HANDLED = {"arena.get_challenge", "arena.clues.list", "arena.clues.get", "arena.time_remaining"}
_FREE_TEXT_PARAMS = {"query", "question", "text", "prompt", "input", "q", "search", "message", "search_query"}
_CORE_PAYLOAD_KEYS = {
    "challenge_type", "challenge_id", "puzzle_id", "description", "rules", "max_time_s",
    "clues", "time_remaining_s", "difficulty", "required_tools",
}
_EXPLORE_MAX_CALLS = 16
_EXPLORE_FANOUT = 6


def _is_stateful_unlock_tool(name: str) -> bool:
    """True for unlock/open/set_key/decrypt-class tool names."""
    return bool(name and _STATEFUL_UNLOCK_ALLOW.search(str(name)))


def _explore_tool_permitted(name: str, *, stateful_unlock_enabled: bool = False) -> bool:
    """Readonly explore policy with an optional gated unlock allowlist.

    Hard-block always wins. Unlock-class tools require ``stateful_unlock_enabled``.
    Other write-ish names stay blocked. Everything else is treated as readonly.
    """
    tool = str(name or "")
    if not tool or _EXPLORE_HARD_BLOCK.search(tool):
        return False
    if _is_stateful_unlock_tool(tool):
        return bool(stateful_unlock_enabled)
    if _EXPLORE_WRITEISH.search(tool):
        return False
    return True


def _seed_stateful_arg_pool(pool: dict[str, list], clues: list[str] | None) -> list[str]:
    """Push clue-derived candidates into secret-like arg buckets for unlock tools.

    Returns the explicit ``code=...``-style values, the only ones blind
    exploration may send to an unlock tool.
    """
    named: list[object] = []
    tokens: list[object] = []
    wholes: list[object] = []
    for clue in clues or []:
        text = str(clue or "").strip()
        if not text:
            continue
        if 1 <= len(text) <= 128:
            wholes.append(text)
        for match in re.finditer(
            r"\b(key|code|password|pin|token|secret|passphrase)\s*[:=]\s*([^\s,;]+)",
            text,
            flags=re.I,
        ):
            field = match.group(1).lower()
            value = match.group(2).strip().strip("`\"'")
            if value:
                bucket = pool.setdefault(field, [])
                if value not in bucket:
                    bucket.append(value)
                named.append(value)
        tokens.extend(re.findall(r"[\"']([^\"']{1,64})[\"']", text))
        tokens.extend(re.findall(r"\b[A-Z0-9][A-Z0-9_\-]{2,31}\b", text))
    # Prefer explicit key=value and short tokens over whole-clue strings.
    candidates = named + tokens + wholes
    for param in _SECRET_PARAM_NAMES:
        bucket = pool.setdefault(param, [])
        for value in candidates:
            if value not in bucket and len(str(value)) <= 128:
                bucket.append(value)
    return [str(value) for value in named]


def _unlock_arguments(argument_sets: list[dict], explicit: set[str]) -> dict | None:
    """The first argument set whose secret-like values all come from explicit clues."""
    for arguments in argument_sets:
        secrets = [str(v) for k, v in arguments.items() if k.lower() in _SECRET_PARAM_NAMES]
        if secrets and all(value in explicit for value in secrets):
            return arguments
    return None


def _collect_values(value: object, pool: dict[str, list], key: str = "") -> None:
    """Index every scalar in a tool result or payload by its field name."""
    if isinstance(value, dict):
        for child_key, child in value.items():
            _collect_values(child, pool, str(child_key).lower())
    elif isinstance(value, list):
        for child in value[:50]:
            _collect_values(child, pool, key)
    elif isinstance(value, (str, int, float)) and key and not isinstance(value, bool):
        bucket = pool.setdefault(key, [])
        if value not in bucket and len(str(value)) <= 512:
            bucket.append(value)


def _pool_values(pool: dict[str, list], param: str) -> list:
    """Values for ``param``: exact field, its plural, or an id-like suffix match."""
    key = param.lower()
    for candidate in (key, f"{key}s", f"{key}es"):
        if pool.get(candidate):
            return pool[candidate]
    if key.endswith("id"):
        for field, values in pool.items():
            if values and (field.endswith(key) or key.endswith(field)) and field.endswith("id"):
                return values
    return []


def _explore_argument_sets(tool_def, agent_id: str, pool: dict[str, list], query: str) -> list[dict]:
    """Argument sets for one tool from its schema; [] when a required value is unknown."""
    schema = getattr(tool_def, "inputSchema", None) or {}
    properties = schema.get("properties") or {}
    required = set(schema.get("required") or [])
    base: dict = {}
    fanout_param, fanout_values = "", []
    for param in properties:
        lowered = param.lower()
        if lowered == "agent_id":
            base[param] = agent_id
            continue
        values = _pool_values(pool, param)
        if values:
            if len(values) > 1 and not fanout_param and param in required:
                fanout_param, fanout_values = param, values[:_EXPLORE_FANOUT]
            else:
                base[param] = values[0]
        elif lowered in _FREE_TEXT_PARAMS:
            base[param] = query
    if any(param not in base and param != fanout_param for param in required):
        return []
    if fanout_param:
        return [{**base, fanout_param: value} for value in fanout_values]
    return [base]


async def _explore_challenge_tools(
    *,
    mcp_client: McpArenaClient,
    tool_defs: list,
    called: set[str],
    agent_id: str,
    payload: dict,
    clues: list[str],
    query: str,
    budget_s: float,
    propose_args=None,
    image_refs: list[str] | None = None,
    stateful_unlock_enabled: bool = False,
) -> list[str]:
    """Call readonly (and optionally gated unlock) challenge tools.

    Event servers can hide the challenge data behind unknown tools, so every
    discovered tool whose arguments can be filled from the payload, the clues
    or earlier tool results is called (concurrently, time-boxed), and results
    that name further tools or ids unlock another round. When
    ``stateful_unlock_enabled`` is set, unlock/open/set_key/decrypt-class tools
    are also tried with clue-seeded secret args. Tools whose required
    arguments cannot be filled that way go once to ``propose_args`` (an LLM
    call) for suggested arguments. Returns evidence lines for the solver prompt.
    """
    deadline = time.monotonic() + max(0.0, budget_s)
    by_name = {str(getattr(t, "name", "")): t for t in tool_defs}
    pool: dict[str, list] = {}
    _collect_values(payload, pool)
    explicit_secrets: set[str] = set()
    if stateful_unlock_enabled:
        explicit_secrets = set(_seed_stateful_arg_pool(pool, clues))
    # One attempt per unlock-class tool: concurrent guesses from every clue
    # token locked a 3-strikes vault before the right code was tried.
    unlock_tried: set[str] = set()
    evidence: list[str] = []
    attempted: set[tuple[str, str]] = set()
    calls = 0
    proposed = False
    for _round in range(4):
        batch: list[tuple[str, dict]] = []
        unfilled = []

        def queue(name: str, arguments: dict) -> None:
            signature = (name, json.dumps(arguments, sort_keys=True, default=str))
            if signature not in attempted and calls + len(batch) < _EXPLORE_MAX_CALLS:
                attempted.add(signature)
                batch.append((name, arguments))

        for name, tool_def in by_name.items():
            if not name or name in _EXPLORE_HANDLED or name in called:
                continue
            if not _explore_tool_permitted(name, stateful_unlock_enabled=stateful_unlock_enabled):
                continue
            argument_sets = _explore_argument_sets(tool_def, agent_id, pool, query)
            if _is_stateful_unlock_tool(name):
                if name in unlock_tried:
                    continue
                chosen = _unlock_arguments(argument_sets, explicit_secrets)
                if chosen is None:
                    unfilled.append(tool_def)
                else:
                    unlock_tried.add(name)
                    queue(name, chosen)
                continue
            if not argument_sets:
                unfilled.append(tool_def)
            for arguments in argument_sets:
                queue(name, arguments)
        remaining = deadline - time.monotonic()
        if not batch and unfilled and propose_args and not proposed and remaining > 6.0:
            proposed = True
            try:
                suggestions = await asyncio.wait_for(
                    asyncio.to_thread(propose_args, unfilled, pool), timeout=min(remaining - 2.0, 15.0)
                )
            except Exception as exc:
                print(f"   (argument proposal skipped: {type(exc).__name__})")
                suggestions = {}
            for tool_def in unfilled:
                schema = getattr(tool_def, "inputSchema", None) or {}
                props = schema.get("properties") or {}
                required = set(schema.get("required") or [])
                limit = 1 if _is_stateful_unlock_tool(tool_def.name) else 3
                for arguments in (suggestions.get(tool_def.name) or [])[:limit]:
                    if not isinstance(arguments, dict) or tool_def.name in unlock_tried:
                        continue
                    if _is_stateful_unlock_tool(tool_def.name):
                        unlock_tried.add(tool_def.name)
                    arguments = {k: v for k, v in arguments.items() if k in props}
                    if "agent_id" in props:
                        arguments["agent_id"] = agent_id
                    if required <= set(arguments):
                        queue(tool_def.name, arguments)
            remaining = deadline - time.monotonic()
        if not batch or remaining <= 1.0:
            break
        calls += len(batch)
        results = await asyncio.gather(
            *(asyncio.wait_for(mcp_client.call_tool(name, args), timeout=remaining) for name, args in batch),
            return_exceptions=True,
        )
        for (name, args), result in zip(batch, results):
            if isinstance(result, BaseException) or (isinstance(result, dict) and result.get("error")):
                continue
            called.add(name)
            _collect_values(result, pool)
            shown = {k: v for k, v in args.items() if k != "agent_id"}
            rendered = _tool_result_text(result)
            if rendered:
                if image_refs is not None:
                    image_refs.extend(_image_refs(json.dumps(result, default=str), limit=4))
                rendered = _strip_image_data(rendered)
                evidence.append(f"{name}({json.dumps(shown, default=str) if shown else ''}): {rendered[:6000]}")
    if evidence:
        print(f"   🔎 Explored tools: {', '.join(sorted({line.split('(')[0] for line in evidence}))}")
    return evidence


def _react_readonly_tools(
    tool_defs: list,
    called: set[str] | None = None,
    *,
    stateful_unlock_enabled: bool = False,
) -> list:
    called = called or set()
    tools = []
    for tool_def in tool_defs:
        name = str(getattr(tool_def, "name", "") or "")
        if not name or name in _EXPLORE_HANDLED or name in called:
            continue
        if not _explore_tool_permitted(name, stateful_unlock_enabled=stateful_unlock_enabled):
            continue
        tools.append(tool_def)
    return tools


def _react_tool_catalog(tool_defs: list) -> str:
    lines = []
    for tool_def in tool_defs[:40]:
        name = str(getattr(tool_def, "name", "") or "")
        desc = str(getattr(tool_def, "description", "") or "")[:240]
        schema = getattr(tool_def, "inputSchema", None) or {}
        props = list((schema.get("properties") or {}).keys())
        required = list(schema.get("required") or [])
        lines.append(
            f"- {name}: {desc or 'no description'}"
            f" | params={props[:12]} required={required[:8]}"
        )
    return "\n".join(lines) if lines else "(no read-only challenge tools discovered)"


def _react_step_prompt(
    *,
    challenge_text: str,
    rules: str,
    clues: list[str],
    evidence: list[str],
    tool_catalog: str,
    step: int,
    max_steps: int,
    stateful_unlock_enabled: bool = False,
) -> str:
    clue_block = "\n".join(f"{i}. {c}" for i, c in enumerate(clues, 1) if str(c).strip()) or "(none)"
    evidence_block = "\n".join(f"- {line}" for line in evidence[-12:]) or "(none yet)"
    unlock_note = (
        "Unlock/open/decrypt-class tools from the catalog are allowed when args are known. "
        if stateful_unlock_enabled
        else ""
    )
    return (
        f"You are exploring MCP tools to solve a black-box challenge.\n"
        f"Step {step}/{max_steps}. Reply with EXACTLY one of:\n"
        f"  CALL <tool_name> {{\"arg\": \"value\"}}\n"
        f"  ANSWER: <final answer in the required format>\n"
        f"Do not explain. Prefer CALL when a tool could unlock the next clue; "
        f"prefer ANSWER only when the evidence already supports a confident final answer.\n"
        f"{unlock_note}"
        f"Never call submit/register/broadcast/draft/delete/status tools.\n\n"
        f"Challenge: {challenge_text}\n"
        f"Required format: {rules or 'a single concise answer'}\n"
        f"Clues:\n{clue_block}\n\n"
        f"Evidence so far:\n{evidence_block}\n\n"
        f"Allowed tools:\n{tool_catalog}"
    )


async def _react_explore_loop(
    *,
    mcp_client: McpArenaClient,
    llm_client,
    model_name: str,
    tool_defs: list,
    called: set[str],
    agent_id: str,
    challenge_text: str,
    rules: str,
    clues: list[str],
    prior_evidence: list[str],
    budget_s: float,
    max_steps: int,
    step_timeout_s: float,
    http_client=None,
    stateful_unlock_enabled: bool = False,
) -> tuple[list[str], str]:
    """Model-driven ReAct exploration with hard step/time/dedupe rails.

    Returns ``(new_evidence_lines, early_answer_or_empty)``. An empty answer
    means the caller should continue with the normal solve pipeline.
    """
    readonly = _react_readonly_tools(tool_defs, stateful_unlock_enabled=stateful_unlock_enabled)
    if not readonly or budget_s <= 1.0 or max_steps <= 0:
        return [], ""

    deadline = time.monotonic() + max(0.0, budget_s)
    catalog = _react_tool_catalog(readonly)
    allowed = {str(getattr(t, "name", "")) for t in readonly}
    evidence = list(prior_evidence[-8:])
    new_evidence: list[str] = []
    attempted: set[tuple[str, str]] = set()
    early_answer = ""

    print(f"   🧭 ReAct explore: up to {max_steps} steps / {budget_s:.1f}s")
    if http_client is not None:
        try:
            http_client.broadcast_thought(agent_id, f"ReAct explore ({max_steps} steps max)...")
        except Exception:
            pass

    for step in range(1, max_steps + 1):
        remaining = deadline - time.monotonic()
        if remaining <= 1.0:
            print("   🧭 ReAct stopped: time budget")
            break
        prompt = _react_step_prompt(
            challenge_text=challenge_text,
            rules=rules,
            clues=clues,
            evidence=evidence,
            tool_catalog=catalog,
            step=step,
            max_steps=max_steps,
            stateful_unlock_enabled=stateful_unlock_enabled,
        )
        call_timeout = min(float(step_timeout_s), max(2.0, remaining - 0.5))
        try:
            response = await asyncio.wait_for(
                asyncio.to_thread(
                    lambda: llm_client.with_options(timeout=call_timeout, max_retries=0).chat.completions.create(
                        model=model_name,
                        messages=[
                            {
                                "role": "system",
                                "content": (
                                    "You explore tools one step at a time. "
                                    "Reply with only CALL <tool> {json} or ANSWER: <final>."
                                ),
                            },
                            {"role": "user", "content": prompt},
                        ],
                        # Reasoning models think first; 512 left them no room to reply.
                        max_tokens=2048,
                        temperature=0.0,
                    )
                ),
                timeout=call_timeout + 1.0,
            )
            raw = (response.choices[0].message.content or "").strip()
        except Exception as exc:
            print(f"   🧭 ReAct step {step} model error: {type(exc).__name__}")
            break

        kind, payload = parse_react_reply(raw)
        if kind == "answer":
            early_answer = str(payload or "").strip()
            print(f"   🧭 ReAct ANSWER at step {step}: {early_answer[:120]}")
            if http_client is not None:
                try:
                    http_client.broadcast_thought(agent_id, f"ReAct answer: {early_answer[:200]}")
                except Exception:
                    pass
            break
        if kind != "call":
            print(f"   🧭 ReAct step {step}: unparseable reply; stopping")
            break

        tool_name, arguments = payload  # type: ignore[misc]
        tool_name = str(tool_name)
        if not isinstance(arguments, dict):
            arguments = {}
        if tool_name not in allowed or not _explore_tool_permitted(
            tool_name, stateful_unlock_enabled=stateful_unlock_enabled
        ):
            print(f"   🧭 ReAct refused blocked tool: {tool_name}")
            note = f"refused non-readonly tool {tool_name}"
            evidence.append(note)
            new_evidence.append(note)
            continue

        # Fill agent_id when the schema expects it.
        tool_def = next((t for t in readonly if getattr(t, "name", "") == tool_name), None)
        schema = getattr(tool_def, "inputSchema", None) or {} if tool_def else {}
        props = schema.get("properties") or {}
        if "agent_id" in props and "agent_id" not in arguments:
            arguments = {**arguments, "agent_id": agent_id}

        signature = react_call_signature(tool_name, arguments)
        if signature in attempted:
            print(f"   🧭 ReAct skipped repeat call: {tool_name}")
            note = f"skipped repeated call {tool_name}"
            evidence.append(note)
            new_evidence.append(note)
            continue
        attempted.add(signature)

        if http_client is not None:
            try:
                shown = {k: v for k, v in arguments.items() if k != "agent_id"}
                http_client.broadcast_thought(
                    agent_id,
                    f"ReAct step {step}: CALL {tool_name} {json.dumps(shown, default=str)[:160]}",
                )
            except Exception:
                pass

        tool_remaining = deadline - time.monotonic()
        if tool_remaining <= 0.5:
            break
        try:
            result = await asyncio.wait_for(
                mcp_client.call_tool(tool_name, arguments),
                timeout=min(float(step_timeout_s), tool_remaining),
            )
        except Exception as exc:
            note = f"{tool_name}(...) error: {type(exc).__name__}"
            evidence.append(note)
            new_evidence.append(note)
            print(f"   🧭 {note}")
            continue

        if isinstance(result, dict) and result.get("error"):
            note = f"{tool_name}(...) error: {result.get('error')}"
            evidence.append(note)
            new_evidence.append(note)
            continue

        called.add(tool_name)
        shown = {k: v for k, v in arguments.items() if k != "agent_id"}
        rendered = _strip_image_data(_tool_result_text(result))[:6000]
        line = f"{tool_name}({json.dumps(shown, default=str) if shown else ''}): {rendered}"
        evidence.append(line)
        new_evidence.append(line)
        print(f"   🧭 ReAct called {tool_name}")

    return new_evidence, early_answer


def _propose_tool_arguments(llm_client, model: str, challenge_text: str, clues: list[str], tool_defs, pool) -> dict:
    """Ask the model for arguments to tools the schema/pool matching could not fill."""
    known = {key: values[:5] for key, values in list(pool.items())[:40]}
    tools = [
        {
            "name": getattr(t, "name", ""),
            "description": str(getattr(t, "description", "") or "")[:400],
            "input_schema": getattr(t, "inputSchema", None) or {},
        }
        for t in tool_defs
    ]
    prompt = (
        f"Challenge: {challenge_text}\n"
        f"Clues: {json.dumps(clues[:20], ensure_ascii=False)}\n"
        f"Values seen so far (field -> values): {json.dumps(known, ensure_ascii=False, default=str)[:4000]}\n"
        f"Read-only tools whose arguments are unknown: {json.dumps(tools, ensure_ascii=False)[:6000]}\n\n"
        "Propose arguments that are most likely to reveal information needed to solve the challenge. "
        "Use exact values from the challenge, clues or seen values where they fit. "
        'Reply with one JSON object only: {"<tool name>": [{<arguments>}, ...]} with at most 3 '
        "argument sets per tool; omit tools you cannot fill sensibly."
    )
    response = llm_client.with_options(timeout=15.0, max_retries=0).chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=2048,
        temperature=0.0,
    )
    raw = response.choices[0].message.content or ""
    match = re.search(r"\{.*\}", raw, re.S)
    if not match:
        return {}
    try:
        value = json.loads(match.group(0))
    except ValueError:
        return {}
    return value if isinstance(value, dict) else {}


def _describe_image(llm_client, model: str, ref: str, question: str) -> str:
    """Vision fallback: the chat model reads the image directly through the proxy."""
    response = llm_client.with_options(timeout=20.0, max_retries=0).chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": [
            {"type": "text", "text": question},
            {"type": "image_url", "image_url": {"url": ref}},
        ]}],
        max_tokens=2048,
        temperature=0.0,
    )
    return (response.choices[0].message.content or "").strip()


_IMAGE_REF = re.compile(
    r"data:image/[a-z0-9+.-]+;base64,[A-Za-z0-9+/=]+|https?://[^\s\"'<>]+?\.(?:png|jpe?g|gif|webp|bmp)(?:\?[^\s\"'<>]*)?",
    re.I,
)
_IMAGE_FETCH_LIMIT = 10 * 1024 * 1024


def _strip_image_data(text: str) -> str:
    """Keep inline image bytes out of the prompt; they are analysed separately."""
    return re.sub(r"data:image/[a-z0-9+.-]+;base64,[A-Za-z0-9+/=]{64,}", "[inline image]", text, flags=re.I)


def _image_refs(*sources: str, limit: int = 2) -> list[str]:
    refs: list[str] = []
    for source in sources:
        for match in _IMAGE_REF.finditer(source or ""):
            if match.group(0) not in refs:
                refs.append(match.group(0))
    return refs[:limit]


def _image_bytes(ref: str) -> bytes | None:
    if ref.startswith("data:"):
        try:
            return base64.b64decode(ref.split(",", 1)[1] + "==")
        except (binascii.Error, ValueError):
            return None
    try:
        with urlopen(Request(ref, headers={"User-Agent": "atom-agent"}), timeout=8) as response:
            return response.read(_IMAGE_FETCH_LIMIT)
    except Exception:
        return None


def _printable_runs(data: bytes, minimum: int = 5) -> list[str]:
    return [m.decode("latin-1") for m in re.findall(rb"[\x20-\x7e]{%d,}" % minimum, data)]


def _image_metadata(data: bytes) -> list[str]:
    """Text hidden in an image file: PNG text chunks, JPEG comments/EXIF, appended bytes.

    Stdlib only (Pillow is not in the lock); pixel-level steganography is left
    to image_analyze.
    """
    found: list[str] = []
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        pos, end = 8, len(data)
        while pos + 8 <= end:
            length = int.from_bytes(data[pos:pos + 4], "big")
            kind = data[pos + 4:pos + 8]
            body = data[pos + 8:pos + 8 + length]
            if kind == b"tEXt":
                found.append("png tEXt: " + body.replace(b"\x00", b": ").decode("latin-1"))
            elif kind == b"zTXt":
                key, _, rest = body.partition(b"\x00")
                try:
                    found.append(f"png zTXt: {key.decode('latin-1')}: " + zlib.decompress(rest[1:]).decode("latin-1"))
                except zlib.error:
                    pass
            elif kind == b"iTXt":
                found.append("png iTXt: " + " | ".join(_printable_runs(body, 2)))
            elif kind == b"IEND":
                trailing = data[pos + 12 + length:]
                if trailing.strip(b"\x00"):
                    found.append("bytes after PNG end: " + " | ".join(_printable_runs(trailing, 3))[:2000])
                break
            pos += 12 + length
    elif data.startswith(b"\xff\xd8"):
        for marker, label in ((b"\xff\xfe", "jpeg comment"), (b"\xff\xe1", "jpeg exif/xmp")):
            for match in re.finditer(re.escape(marker), data[:200_000]):
                length = int.from_bytes(data[match.end():match.end() + 2], "big")
                runs = _printable_runs(data[match.end() + 2:match.end() + length])
                if runs:
                    found.append(f"{label}: " + " | ".join(runs)[:2000])
        end = data.rfind(b"\xff\xd9")
        if end != -1 and data[end + 2:].strip(b"\x00"):
            found.append("bytes after JPEG end: " + " | ".join(_printable_runs(data[end + 2:], 3))[:2000])
    return found


async def _image_evidence(
    *, mcp_client: McpArenaClient, tools: list[str], tool_defs, refs: list[str], question: str,
    agent_id: str, llm_api_key: str, arena_api_key: str, budget_s: float, vision=None,
) -> list[str]:
    """image_analyze plus metadata for images found in a text challenge.

    Practice refuses image_analyze unless the assignment is an image
    challenge, so ``vision`` (a chat call with the image attached) answers
    when the tool gives nothing.
    """
    if not refs or budget_s <= 2:
        return []
    analyze_args = build_image_tool_arguments(
        tool_defs, "image_analyze", selected_model="", llm_api_key=llm_api_key, arena_api_key=arena_api_key
    )

    async def one(ref: str) -> list[str]:
        label = ref if not ref.startswith("data:") else ref[:30] + "..."
        lines: list[str] = []
        jobs = [asyncio.to_thread(lambda: _image_metadata(_image_bytes(ref) or b""))]
        if "image_analyze" in tools:
            jobs.append(mcp_client.call_tool(
                "image_analyze", {"image_uri": ref, "question": question, "agent_id": agent_id, **analyze_args}
            ))
        results = await asyncio.gather(*jobs, return_exceptions=True)
        if isinstance(results[0], list) and results[0]:
            lines.append(f"image.metadata({label}): " + " || ".join(results[0]))
        if len(results) > 1 and isinstance(results[1], dict) and results[1].get("text"):
            lines.append(f"image_analyze({label}): {str(results[1]['text'])[:4000]}")
        elif vision is not None:
            try:
                described = await asyncio.to_thread(vision, ref, question)
            except Exception as exc:
                print(f"   (vision fallback failed: {type(exc).__name__})")
                described = ""
            if described:
                lines.append(f"vision({label}): {described[:4000]}")
        return lines

    try:
        groups = await asyncio.wait_for(asyncio.gather(*(one(ref) for ref in refs)), timeout=budget_s)
    except asyncio.TimeoutError:
        return []
    evidence = [line for group in groups for line in group]
    if evidence:
        print(f"   🖼️  Image evidence from {len(refs)} image(s)")
    return evidence


def _payload_evidence(payload: dict) -> list[str]:
    """Challenge payload fields the prompt would otherwise never show."""
    lines = []
    for key, value in payload.items():
        if key in _CORE_PAYLOAD_KEYS:
            continue
        text = _strip_image_data(_tool_result_text(value))
        if text:
            lines.append(f"challenge.{key}: {text[:20000]}")
    return lines


def _build_context(
    *,
    challenge_type: str,
    description: str,
    rules: str,
    clues: list[str] | None = None,
    max_time_s: int = 0,
    available_models: list[str] | None = None,
    time_remaining_s: float = 0.0,
    tokens_used: int = 0,
    image_url: str | None = None,
    difficulty: str = "",
    required_tools: list[str] | None = None,
) -> ChallengeContext:
    return ChallengeContext(
        challenge_type=challenge_type,
        difficulty=str(difficulty or "").strip() or "unknown",
        challenge_text=description,
        description=description,
        rules=rules,
        clues=list(clues or []),
        time_remaining_s=time_remaining_s,
        max_time_s=max_time_s,
        available_models=list(available_models or []),
        tools_used=[],
        tokens_used=tokens_used,
        required_tools=list(required_tools or []),
        image_url=image_url,
    )


def _coerce_nonnegative_int(value: object, default: int = 0) -> int:
    try:
        return max(0, int(value if value is not None else default))
    except (TypeError, ValueError):
        return default


def _fetch_proxy_usage(
    llm_host: str,
    api_key: str,
    agent_id: str,
    scope_id: str | None = None,
) -> dict[str, int] | None:
    """Best-effort fetch of proxy usage for one agent, scoped when possible."""
    if not llm_host or not api_key or not agent_id:
        return None
    encoded_agent_id = quote(agent_id, safe="")

    def _read_usage(url: str) -> dict[str, int] | None:
        request = Request(
            url,
            headers={"Authorization": f"Bearer {api_key}", "Accept": "application/json"},
            method="GET",
        )
        with urlopen(request, timeout=1.0) as response:
            payload = json.loads(response.read().decode("utf-8"))
        usage = payload.get("usage")
        if not isinstance(usage, dict):
            return None
        return {
            "prompt_tokens": _coerce_nonnegative_int(usage.get("prompt_tokens")),
            "completion_tokens": _coerce_nonnegative_int(usage.get("completion_tokens")),
            "total_tokens": _coerce_nonnegative_int(usage.get("total_tokens")),
        }

    if scope_id:
        encoded_scope_id = quote(scope_id, safe="")
        scoped_url = f"{llm_host.rstrip('/')}/usage/{encoded_scope_id}/{encoded_agent_id}"
        try:
            return _read_usage(scoped_url)
        except HTTPError as exc:
            if exc.code not in {400, 404}:
                raise

    aggregate_url = f"{llm_host.rstrip('/')}/usage/{encoded_agent_id}"
    return _read_usage(aggregate_url)


def _build_live_metrics(model_name: str, usage: dict[str, int] | None, elapsed_ms: int) -> dict[str, object]:
    usage = usage or {}
    prompt_tokens = _coerce_nonnegative_int(usage.get("prompt_tokens"))
    completion_tokens = _coerce_nonnegative_int(usage.get("completion_tokens"))
    total_tokens = _coerce_nonnegative_int(usage.get("total_tokens"))
    return {
        "model_name": str(model_name or "").strip(),
        "total_tokens": str(total_tokens),
        "prompt_tokens": str(prompt_tokens),
        "completion_tokens": str(completion_tokens),
        "total_time_ms": int(max(0, elapsed_ms)),
    }


# A retry with another model needs time to think and answer.
RETRY_MIN_REMAINING_S = 30.0


def _next_ranked_model(ranked_models: list[str], current: str) -> str:
    """The first ranked model after ``current``, or "" when there is none."""
    remaining = [model for model in ranked_models if model != current]
    if current in ranked_models:
        after = ranked_models[ranked_models.index(current) + 1 :]
        remaining = [model for model in after if model != current] or remaining
    return remaining[0] if remaining else ""


async def _retry_after_length_stop(result, *, ranked_models, remaining_s, solve_with):
    """Retry once with the next ranked model when the first ran out of tokens.

    ``result`` is solve_challenge's tuple. A reasoning model that spends its
    whole token budget thinking returns no answer with finish_reason
    "length"; asking it again would do the same, so another model gets one
    try while enough time remains. Token usage and time add up across both.
    """
    answer, _raw, model_name, usage, _ttft, total_time_ms = result
    if _is_invalid_answer_candidate(answer):
        answer = ""
    if answer or usage.get("finish_reason") != "length":
        return result
    tokens_spent = int(usage.get("completion_tokens", 0) or 0)
    print(f"   ⚠️  {model_name} used all {tokens_spent} tokens thinking and gave no answer.")
    retry_model = _next_ranked_model(ranked_models, model_name)
    left_s = await remaining_s()
    if not retry_model or left_s < RETRY_MIN_REMAINING_S:
        print(f"   Not retrying ({left_s:.0f}s left). Tune text_max_tokens or rank_models in my_strategy.py.")
        return result
    print(f"   Retrying with {retry_model}. Tune text_max_tokens or rank_models in my_strategy.py.")
    retried = await solve_with(retry_model)
    r_answer, r_raw, r_model, r_usage, r_ttft, r_time_ms = retried
    merged_usage = dict(r_usage)
    for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
        merged_usage[key] = int(r_usage.get(key, 0) or 0) + int(usage.get(key, 0) or 0)
    return r_answer, r_raw, r_model, merged_usage, r_ttft, total_time_ms + r_time_ms


async def solve_challenge(
    challenge,
    clues: list[str],
    llm_client,
    model_name: str,
    strategy: MyStrategy,
    ctx: ChallengeContext,
    *,
    http_client=None,
    agent_id: str = "",
    broadcast_thought: bool = True,
    evidence_lines: list[str] | None = None,
    ticker: ReasoningTicker | None = None,
):
    """Solve the challenge using the selected LLM model.
    
    When http_client and agent_id are provided, streams reasoning to Agent Gauntlet in real time.
    
    Returns:
        tuple: (extracted_answer, raw_response, model_name, usage_dict, ttft_ms, total_time_ms)
    """
    
    _ = challenge
    _ = clues
    prompt = strategy.build_solver_prompt(ctx)
    guardrails = str(getattr(strategy, "output_guardrails", "") or "").strip() or (
        "- Return only your final answer line.\n"
        "- Do not output tool-call markup, XML tags, or thinking traces."
    )
    prompt = f"{prompt}\n\nOutput guardrails:\n{guardrails}"
    system_msg = strategy.build_system_prompt(ctx)
    llm_params = strategy.get_llm_params(ctx)
    max_tokens = int(llm_params.get("max_tokens", 8192))
    temperature = float(llm_params.get("temperature", 0.0))
    
    # Track timing
    start_ms = time.time() * 1000
    ttft_ms = 0
    raw_content_parts = []
    # Kept apart so the answer comes from the final reply, as in the
    # non-streaming path; reasoning can hold draft "ANSWER:" lines.
    reply_parts: list[str] = []
    reasoning_parts: list[str] = []
    pending_broadcast = ""
    _BROADCAST_CHUNK = 80  # chars before sending a thought

    def _flush_broadcast(force: bool = False) -> None:
        nonlocal pending_broadcast
        if not http_client or not agent_id or not broadcast_thought:
            return
        if force or len(pending_broadcast) >= _BROADCAST_CHUNK or "\n" in pending_broadcast:
            chunk = pending_broadcast.strip()
            pending_broadcast = ""
            if chunk:
                try:
                    http_client.broadcast_thought(agent_id, chunk[:300])
                except Exception:
                    pass

    stream_enabled = os.getenv("LLM_STREAM", "1").lower() not in {"0", "false", "no"}
    usage = None
    finish_reason = ""
    if stream_enabled and http_client and agent_id:
        # Stream and broadcast in real time
        try:
            stream = llm_client.chat.completions.create(
                model=model_name,
                messages=[
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=max_tokens,
                temperature=temperature,
                stream=True,
            )
            header_sent = False
            for chunk in stream:
                if chunk.choices and getattr(chunk.choices[0], "finish_reason", None):
                    finish_reason = str(chunk.choices[0].finish_reason)
                if chunk.choices and chunk.choices[0].delta:
                    delta = chunk.choices[0].delta
                    content = delta.content or ""
                    reasoning = getattr(delta, "reasoning_content", None) or getattr(delta, "reasoning", None) or ""
                    text = reasoning or content
                    if ticker is not None:
                        ticker.feed(reasoning=reasoning, answer=content)
                    if reasoning:
                        reasoning_parts.append(reasoning)
                    if content:
                        reply_parts.append(content)
                    if text:
                        if not ttft_ms:
                            ttft_ms = int(time.time() * 1000 - start_ms)
                        raw_content_parts.append(text)
                        if broadcast_thought:
                            if not header_sent:
                                http_client.broadcast_thought(agent_id, "💭 LLM Reasoning:")
                                header_sent = True
                            pending_broadcast += text
                            _flush_broadcast()
                if hasattr(chunk, "usage") and chunk.usage:
                    usage = chunk.usage
            _flush_broadcast(force=True)
        except Exception as e:
            stream_enabled = False
            raw_content_parts = []
            if "stream" in str(e).lower() or "Stream" in str(e):
                pass  # Fall through to non-streaming
            else:
                raise

    if not stream_enabled or not raw_content_parts:
        # Non-streaming fallback
        response = llm_client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": system_msg},
                {"role": "user", "content": prompt},
            ],
            max_tokens=max_tokens,
            temperature=temperature,
        )
        raw_content = response.choices[0].message.content or ""
        finish_reason = str(getattr(response.choices[0], "finish_reason", "") or "")
        usage = response.usage
        ttft_ms = ttft_ms or getattr(response, "ttft_ms", 0) or int((time.time() * 1000 - start_ms) * 0.1)
    else:
        reply = "".join(reply_parts)
        raw_content = reply if reply.strip() else "".join(reasoning_parts)

    total_time_ms = int(time.time() * 1000 - start_ms)
    answer = extract_answer(raw_content)
    if _is_invalid_answer_candidate(answer):
        answer = ""
    if not answer and evidence_lines:
        answer = _derive_answer_from_evidence(
            llm_client=llm_client,
            model_name=model_name,
            challenge_description=str(ctx.description or ""),
            challenge_rules=str(ctx.rules or ""),
            evidence_lines=list(evidence_lines or []),
            max_tokens=max_tokens,
        )
        if _is_invalid_answer_candidate(answer):
            answer = ""
    # A model that ran out of tokens while thinking would only do it again;
    # the caller retries with another model instead.
    if not answer and finish_reason != "length":
        strict_system_msg = (
            "Return only one line in exact format: ANSWER: <final answer>. "
            "No preamble, no tags, no explanation, no additional lines."
        )
        try:
            strict_response = llm_client.chat.completions.create(
                model=model_name,
                messages=[
                    {"role": "system", "content": strict_system_msg},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=max_tokens,
                temperature=min(temperature, 0.0),
                stream=False,
            )
            raw_content = strict_response.choices[0].message.content or ""
            usage = strict_response.usage
            total_time_ms = int(time.time() * 1000 - start_ms)
            answer = extract_answer(raw_content)
        except Exception:
            pass
    if _is_invalid_answer_candidate(answer):
        answer = ""

    usage_dict = {
        "finish_reason": finish_reason,
        "prompt_tokens": getattr(usage, "prompt_tokens", 0) if usage else 0,
        "completion_tokens": getattr(usage, "completion_tokens", 0) if usage else 0,
        "total_tokens": getattr(usage, "total_tokens", 0) if usage else 0,
    }
    # Streams usually carry no usage; estimate from everything streamed,
    # reasoning included, not only the reply the answer was read from.
    streamed_text = "".join(raw_content_parts) or raw_content
    if not usage_dict["total_tokens"] and streamed_text:
        usage_dict["total_tokens"] = len(streamed_text.split()) * 2  # rough estimate
    ttft_ms = ttft_ms or int(total_time_ms * 0.1)

    return answer, raw_content, model_name, usage_dict, ttft_ms, total_time_ms


async def main():
    """Main agent loop."""
    strategy = MyStrategy()
    agent_id = (
        os.getenv("AGENT_ID")
        or str(getattr(strategy, "agent_id", "")).strip()
        or "simple-agent"
    ).strip()
    agent_name = (
        os.getenv("AGENT_NAME")
        or str(getattr(strategy, "agent_name", "")).strip()
        or "Team Nova"
    ).strip()
    os.environ["AGENT_ID"] = agent_id
    # Practice is shared: a default id lets another team's run replace yours.
    id_problem = agent_id_problem(os.environ["AGENT_ID"])
    if id_problem:
        raise SystemExit(f"❌ {id_problem}")
    os.environ["AGENT_NAME"] = agent_name
    print(f"🤖 {agent_name} starting...")
    print(f"   Agent ID: {agent_id}")

    ensure_connected()

    # Initialize clients
    api_base = get_api_base()
    mcp_url = get_mcp_url()
    llm_host = get_proxy_host()
    api_key = get_arena_api_key()
    llm_api_key = api_key

    print(f"   API: {api_base}")
    print(f"   MCP: {mcp_url}")
    print(f"   LLM: {llm_host}")
    print()

    # HTTP client for Agent Gauntlet coordination
    http_client = HttpArenaClient(api_base=api_base, api_key=api_key)

    if not HAS_OPENAI:
        raise RuntimeError("Missing dependency: openai. Install with `pip install openai`.")
    
    # Step 1: Register with Agent Gauntlet
    print("📝 Registering with Agent Gauntlet...")
    session = http_client.register(agent_id, agent_name)
    print(f"   Session: {session.session_id}")
    print(f"   Status: {session.status}")
    session_monitor = monitor_session(http_client, agent_id).start()
    http_client = _QueuedNotes(http_client)

    # Step 2: Get challenge from MCP
    print("\n🎯 Getting challenge...")
    async with McpArenaClient(mcp_url) as mcp_client:
        tools = await mcp_client.list_tools()
        tool_defs = await mcp_client.list_tool_defs()
        modality = McpArenaClient.detect_modality(tools, agent_id=agent_id)
        image_tool_proxy_args: dict[str, dict[str, str]] = {}
        usage_scope = http_client.fetch_usage_scope() or resolve_usage_scope()
        if usage_scope:
            os.environ["ARENA_USAGE_SCOPE"] = usage_scope
        # Fetched before the challenge timer starts; refetched after only if empty.
        available_models = fetch_available_models(llm_host, llm_api_key)

        live_prompt_tokens = 0
        live_completion_tokens = 0
        live_total_tokens = 0
        active_model_name = ""
        metrics_started_ms = 0.0
        reporter_stop = asyncio.Event()
        metrics_task: asyncio.Task | None = None

        def _elapsed_metrics_ms() -> int:
            if metrics_started_ms <= 0:
                return 0
            return int(max(0.0, time.time() * 1000 - metrics_started_ms))

        async def _refresh_live_usage() -> None:
            nonlocal live_prompt_tokens, live_completion_tokens, live_total_tokens
            try:
                usage = await asyncio.to_thread(
                    _fetch_proxy_usage,
                    llm_host,
                    llm_api_key,
                    agent_id,
                    usage_scope,
                )
            except Exception:
                usage = None
            if not isinstance(usage, dict):
                return
            live_prompt_tokens = _coerce_nonnegative_int(usage.get("prompt_tokens"))
            live_completion_tokens = _coerce_nonnegative_int(usage.get("completion_tokens"))
            live_total_tokens = _coerce_nonnegative_int(usage.get("total_tokens"))

        async def _push_live_status(status: str = "running") -> None:
            await _refresh_live_usage()
            try:
                await asyncio.to_thread(
                    http_client.update_status,
                    agent_id,
                    status,
                    _build_live_metrics(
                        active_model_name,
                        {
                            "prompt_tokens": live_prompt_tokens,
                            "completion_tokens": live_completion_tokens,
                            "total_tokens": live_total_tokens,
                        },
                        _elapsed_metrics_ms(),
                    ),
                )
            except Exception:
                return

        async def _runtime_metrics_reporter() -> None:
            while not reporter_stop.is_set():
                await _push_live_status("running")
                try:
                    await asyncio.wait_for(reporter_stop.wait(), timeout=1.0)
                except asyncio.TimeoutError:
                    continue

        async def _start_metrics_reporter(model_name: str) -> None:
            nonlocal active_model_name, metrics_started_ms, metrics_task
            active_model_name = str(model_name or "").strip()
            metrics_started_ms = time.time() * 1000
            reporter_stop.clear()
            # The reporter pushes immediately; awaiting a push here only
            # delayed the solve.
            metrics_task = asyncio.create_task(_runtime_metrics_reporter())

        async def _stop_metrics_reporter() -> None:
            reporter_stop.set()
            if metrics_task is not None and not metrics_task.done():
                metrics_task.cancel()
            # Final status push runs alongside submit instead of before it.
            asyncio.create_task(_push_live_status("running"))

        if modality == "image":
            challenge = None
            while True:
                try:
                    challenge = await mcp_client.get_image_challenge(agent_id)
                    break
                except McpArenaError as e:
                    message = str(e).lower()
                    if "locked" in message or "waiting for organizer" in message:
                        print("   Lobby open; waiting for organizer to start battle...")
                        await asyncio.sleep(3.0)
                    else:
                        raise
            print_challenge(challenge)
            usage_scope = http_client.fetch_usage_scope() or resolve_usage_scope()
            if usage_scope:
                os.environ["ARENA_USAGE_SCOPE"] = usage_scope

            available_models = available_models or fetch_available_models(llm_host, llm_api_key)
            image_rules = "\n".join(
                part
                for part in (challenge.prompt, challenge.reference_notes)
                if isinstance(part, str) and part.strip()
            )
            image_prompt = (challenge.prompt or challenge.description or "").strip()
            image_ctx = _build_context(
                challenge_type=challenge.challenge_type,
                description=challenge.description,
                rules=image_rules,
                max_time_s=challenge.max_time_s,
                available_models=available_models,
                image_url=challenge.input_image_uri or None,
                difficulty=challenge.difficulty,
            )
            ranked_models = strategy.rank_models(image_ctx, available_models)
            model_name = strategy.pick_model("solve", ranked_models, image_ctx)
            model_name = require_explicit_model(
                model_name,
                available_models,
                source="python_simple agent",
            )
            image_tool_proxy_args = {
                tool_name: build_image_tool_arguments(
                    tool_defs,
                    tool_name,
                    selected_model=model_name,
                    llm_api_key=llm_api_key,
                    arena_api_key=api_key,
                )
                for tool_name in ("image_edit", "image_generate", "image_analyze")
            }
            print(f"   Selected model: {model_name}")
            http_client.broadcast_thought(agent_id, f"Selected planner model: {model_name}")
            await _start_metrics_reporter(model_name)

            start_ms = time.time() * 1000
            prompt_text = strategy.build_image_prompt(image_ctx).strip() or image_prompt
            image_tools = [
                tool_name
                for tool_name in ("image_edit", "image_generate", "image_analyze")
                if tool_name in tools
            ]
            image_tool_sequence = _plan_image_tool_sequence(
                strategy,
                image_ctx,
                image_tools,
            )
            selected_tool = image_tool_sequence[-1] if image_tool_sequence else ""
            tool_result: dict = {}
            mcp_session_dead = False

            async def _call_image_tool(name: str, arguments: dict) -> dict:
                nonlocal mcp_session_dead
                try:
                    result = await mcp_client.call_tool(name, arguments)
                    return result if isinstance(result, dict) else {}
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    mcp_session_dead = True
                    print(f"   Image tool {name} failed ({type(exc).__name__}): {exc}")
                    return {}

            if (
                len(image_tool_sequence) > 1
                and image_tool_sequence[0] == "image_analyze"
                and challenge.input_image_uri
            ):
                print("   Using image_analyze before output tool")
                analysis_result = await _call_image_tool(
                    "image_analyze",
                    {
                        "image_uri": challenge.input_image_uri,
                        "question": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_analyze", {}),
                    },
                )
                analysis_text = str(analysis_result.get("text") or "").strip()
                if analysis_text:
                    http_client.broadcast_thought(
                        agent_id,
                        f"Image analysis: {analysis_text[:180]}",
                    )
                    prompt_text = (
                        f"{prompt_text}\n\n"
                        "Source-image analysis to preserve while transforming: "
                        f"{analysis_text[:1000]}"
                    )
            if (
                selected_tool == "image_edit"
                and challenge.input_image_uri
                and "image_edit" in image_tools
            ):
                print("   Using image_edit tool")
                tool_result = await _call_image_tool(
                    "image_edit",
                    {
                        "image_uri": challenge.input_image_uri,
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_edit", {}),
                    },
                )
            elif selected_tool == "image_generate" and "image_generate" in image_tools:
                print("   Using image_generate tool")
                tool_result = await _call_image_tool(
                    "image_generate",
                    {
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_generate", {}),
                    },
                )
            elif (
                selected_tool == "image_analyze"
                and challenge.input_image_uri
                and "image_analyze" in image_tools
            ):
                print("   Using image_analyze tool (no image output tool available)")
                tool_result = await _call_image_tool(
                    "image_analyze",
                    {
                        "image_uri": challenge.input_image_uri,
                        "question": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_analyze", {}),
                    },
                )
                analysis_text = str(tool_result.get("text") or "").strip()
                if analysis_text:
                    http_client.broadcast_thought(
                        agent_id,
                        f"Image analysis: {analysis_text[:180]}",
                    )
            elif challenge.input_image_uri and "image_edit" in image_tools:
                selected_tool = "image_edit"
                tool_result = await _call_image_tool(
                    "image_edit",
                    {
                        "image_uri": challenge.input_image_uri,
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_edit", {}),
                    },
                )
            elif "image_generate" in image_tools:
                selected_tool = "image_generate"
                tool_result = await _call_image_tool(
                    "image_generate",
                    {
                        "prompt": prompt_text,
                        "agent_id": agent_id,
                        **image_tool_proxy_args.get("image_generate", {}),
                    },
                )

            if tool_result.get("error"):
                print(f"   Tool warning: {tool_result.get('error')}")

            output_image_uri = str(tool_result.get("image_uri") or "").strip()
            if not output_image_uri and challenge.input_image_uri:
                output_image_uri = challenge.input_image_uri
            if not output_image_uri:
                if mcp_session_dead:
                    await session_monitor.stop()
                    raise RuntimeError(
                        "Image MCP tool failed and no input_image_uri is available "
                        "to submit; refusing to invent image bytes"
                    )
                output_image_uri = BLANK_PNG_DATA_URI

            total_time_ms = int(time.time() * 1000 - start_ms)
            await _stop_metrics_reporter()
            http_client.flush()
            client_metrics = {
                "model_name": model_name,
                "planner_tool": selected_tool,
                "total_tokens": str(live_total_tokens),
                "prompt_tokens": str(live_prompt_tokens),
                "completion_tokens": str(live_completion_tokens),
                "ttft_ms": 0,
                "total_time_ms": total_time_ms,
            }
            if mcp_session_dead:
                await session_monitor.stop()
                print("   MCP session unavailable; submitting image over REST")
                image_submit_result = http_client.submit(
                    agent_id,
                    answer=output_image_uri,
                    client_metrics=client_metrics,
                    challenge_type="image",
                )
            else:
                image_submit_result = await mcp_client.submit_image(
                    agent_id=agent_id,
                    image_uri=output_image_uri,
                    client_metrics=client_metrics,
                    rationale="simple_agent dynamic image flow",
                )
            for line in submission_summary_lines(image_submit_result):
                print(f"   {line}")
            await session_monitor.stop()
            # Last steps, after the submission is final; neither raises.
            print(f"   Image: {save_submitted_image(agent_id, output_image_uri, REPO_ROOT)}")
            if isinstance(image_submit_result, dict):
                image_result = image_submit_result
            else:  # REST fallback returns a SubmitResult
                image_result = {
                    "accepted": getattr(image_submit_result, "accepted", None),
                    "score": getattr(image_submit_result, "score", None),
                }
            score = image_result.get("score") if isinstance(image_result.get("score"), dict) else {}
            run_record = {
                "agent_id": agent_id,
                "challenge": challenge_record(challenge),
                "model": model_name,
                "image_tool_sequence": image_tool_sequence,
                "result": {
                    "accepted": image_result.get("accepted"),
                    "score": {key: value for key, value in score.items() if key != "output_image_uri"},
                },
            }
            print(f"   Run record: {save_run_record(agent_id, run_record, REPO_ROOT)}")
            _append_run_log(agent_id, run_record)
            print("\n✅ Agent completed!")
            return

        # Probe the strategy's preferred text models before the challenge
        # timer starts; drop any that fail, unless every probe failed (then
        # the proxy itself is the problem and failover handles it later).
        probe_targets = list(getattr(strategy, "probe_models", lambda _models: [])(available_models) or [])
        if probe_targets:
            probe_client = OpenAI(
                base_url=llm_host,
                api_key=llm_api_key,
                default_headers=build_proxy_headers(agent_id, usage_scope),
            )
            healthy = await asyncio.to_thread(_probe_models, probe_client, probe_targets)
            dead = set(probe_targets) - set(healthy)
            if healthy and dead:
                print(f"   Dropping unhealthy models: {', '.join(sorted(dead))}")
                available_models = [m for m in available_models if m not in dead]

        # Wait for organizer to start (challenge is locked while lobby is open)
        challenge = None
        while True:
            try:
                challenge = await mcp_client.get_challenge(agent_id)
                break
            except McpArenaError as e:
                message = str(e).lower()
                if "locked" in message or "waiting for organizer" in message:
                    print("   Lobby open; waiting for organizer to start battle...")
                    await asyncio.sleep(3.0)
                else:
                    raise
        print_challenge(challenge)
        usage_scope = http_client.fetch_usage_scope() or resolve_usage_scope()
        if usage_scope:
            os.environ["ARENA_USAGE_SCOPE"] = usage_scope
        llm_client = OpenAI(
            base_url=llm_host,
            api_key=llm_api_key,
            default_headers=build_proxy_headers(agent_id, usage_scope),
        )
        print("   LLM: Enabled")
        print()

        challenge_received_s = time.monotonic()
        challenge_difficulty = str(challenge.raw_data.get("difficulty") or "")
        declared_required = [
            str(name) for name in (challenge.raw_data.get("required_tools") or []) if str(name).strip()
        ]
        available_models = available_models or fetch_available_models(llm_host, llm_api_key)
        model_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            description=challenge.description,
            rules=challenge.rules,
            max_time_s=challenge.max_time_s,
            available_models=available_models,
            difficulty=challenge_difficulty,
            required_tools=declared_required,
        )
        ranked_models = strategy.rank_models(model_ctx, available_models)
        model_name = strategy.pick_model("solve", ranked_models, model_ctx)
        model_name = require_explicit_model(
            model_name,
            available_models,
            source="python_simple agent",
        )
        print(f"   Selected model: {model_name}")
        await _start_metrics_reporter(model_name)
        
        # Broadcast thought
        http_client.broadcast_thought(agent_id, "Reading challenge and clues...")
        
        # Get all clues
        print("\n📖 Reading clues...")
        clue_ids = await mcp_client.list_clues(agent_id)
        # Fetched concurrently: one round trip instead of one per clue.
        clue_infos = await asyncio.gather(
            *(mcp_client.get_clue(clue_id, agent_id) for clue_id in clue_ids)
        )
        clues = [clue.text for clue in clue_infos]
        if not clues:
            clues = [str(clue_text) for clue_text in challenge.clues]

        research_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            description=challenge.description,
            rules=challenge.rules,
            clues=clues,
            max_time_s=challenge.max_time_s,
            available_models=ranked_models,
            difficulty=challenge_difficulty,
            required_tools=declared_required,
        )
        search_tools = [str(name) for name in tools if "search" in str(name).lower()]
        search_queries: list[str] = []
        if search_tools and getattr(strategy, "wants_search", lambda _ctx: False)(research_ctx):
            search_queries = list(getattr(strategy, "search_queries", lambda _ctx: [])(research_ctx) or [])
            if search_queries:
                print(f"   🌐 Search plan: {' | '.join(search_queries)}")
        required_called: set[str] = set()
        tool_evidence_lines = await _enforce_required_tool_calls(
            mcp_client=mcp_client,
            agent_id=agent_id,
            challenge_type=str(challenge.challenge_type or ""),
            description=str(challenge.description or ""),
            rules=str(challenge.rules or ""),
            clues=clues,
            available_tool_names=[str(name) for name in tools],
            http_client=http_client,
            extra_context=str(getattr(challenge, "extra_text", "") or ""),
            declared_required=[
                name
                for name in declared_required
                if name not in {"arena.get_challenge", "arena.clues.list"}
                and not (name == "arena.clues.get" and clue_ids)
            ],
            search_queries=search_queries,
            tool_defs=tool_defs,
            payload=dict(challenge.raw_data),
            succeeded=required_called,
        )
        submit_reserve_s = float(getattr(strategy, "submit_reserve_s", 10.0))

        def _solve_budget_s() -> float:
            elapsed = time.monotonic() - challenge_received_s
            return float(challenge.time_remaining_s or challenge.max_time_s or 60) - elapsed - submit_reserve_s

        # One follow-up search when the first results only point at the
        # answer (multi-hop questions); skipped when time is short.
        if search_queries and hasattr(strategy, "follow_up_prompt") and _solve_budget_s() > 30.0:
            results = [line for line in tool_evidence_lines if line.split("(")[0] in search_tools]
            follow_up = await asyncio.to_thread(
                _follow_up_query, llm_client, model_name, strategy, research_ctx, results, min(20.0, _solve_budget_s() / 4)
            )
            if follow_up and follow_up not in search_queries:
                print(f"   🌐 Follow-up search: {follow_up}")
                http_client.broadcast_thought(agent_id, f"Follow-up search: {follow_up}")
                tool_evidence_lines += await _search_calls(
                    mcp_client, search_tools[0], [follow_up], agent_id,
                    next((t for t in tool_defs if getattr(t, "name", "") == search_tools[0]), None),
                )

        # Required tools that failed every argument shape stay eligible, so
        # exploration retries them with pooled values or proposed arguments.
        explored_called = (
            required_called
            | {"arena.get_challenge", "arena.clues.list", "arena.clues.get"}
            | (set(search_tools) if search_queries else set())
        )
        # Unknown read-only tools may hold the challenge data; explore them
        # within an adaptive slice of the time budget, leaving most for solving.
        if hasattr(strategy, "explore_time_budget"):
            explore_budget_s = float(
                strategy.explore_time_budget(
                    research_ctx,
                    available_tool_names=[str(name) for name in tools],
                    called_tools=explored_called,
                    solve_budget_s=_solve_budget_s(),
                )
            )
        else:
            explore_budget_s = min(
                float(getattr(strategy, "explore_budget_s", 15.0)), max(0.0, _solve_budget_s() / 3)
            )
        # Shared exploration budget: keep headroom for the optional ReAct loop
        # so blind tool probing cannot consume the whole solve slice.
        react_reserve_s = (
            float(strategy.react_time_budget(_solve_budget_s()))
            if getattr(strategy, "react_explore_enabled", False) and hasattr(strategy, "react_time_budget")
            else 0.0
        )
        if react_reserve_s > 0 and explore_budget_s > 0:
            explore_budget_s = min(explore_budget_s, max(0.0, _solve_budget_s() - react_reserve_s))
        if explore_budget_s > 0:
            print(f"   🔎 Explore budget: {explore_budget_s:.1f}s")
        found_image_refs: list[str] = []
        stateful_unlock = bool(getattr(strategy, "stateful_unlock_enabled", False))
        tool_evidence_lines += await _explore_challenge_tools(
            mcp_client=mcp_client,
            tool_defs=tool_defs,
            called=explored_called,
            agent_id=agent_id,
            payload=dict(challenge.raw_data),
            clues=clues,
            query=str(challenge.description or ""),
            budget_s=explore_budget_s,
            propose_args=lambda defs, pool: _propose_tool_arguments(
                llm_client, model_name, str(challenge.description or ""), clues, defs, pool
            ),
            image_refs=found_image_refs,
            stateful_unlock_enabled=stateful_unlock,
        )
        missing_required = [
            name for name in declared_required
            if name not in explored_called and not (name == "arena.clues.get" and clue_ids)
        ]
        if missing_required:
            print(f"   ⚠️  Required tool(s) never answered: {', '.join(missing_required)}")
            http_client.broadcast_thought(agent_id, f"Required tools not covered: {', '.join(missing_required)}")
        # Text challenges can carry images (hidden patterns, metadata): analyse
        # them and read their metadata, still answering in text.
        found_image_refs = _image_refs(json.dumps(challenge.raw_data, default=str), *clues) + found_image_refs
        tool_evidence_lines += await _image_evidence(
            mcp_client=mcp_client,
            tools=[str(name) for name in tools],
            tool_defs=tool_defs,
            refs=list(dict.fromkeys(found_image_refs))[:2],
            question=(
                f"{challenge.description}\n{challenge.rules}\n"
                "Describe everything relevant to this question, including any small or hidden text, "
                "symbols, patterns, anomalies or encoded content."
            ),
            agent_id=agent_id,
            llm_api_key=llm_api_key,
            arena_api_key=api_key,
            budget_s=min(25.0, max(0.0, _solve_budget_s() / 3)),
            vision=lambda ref, question: _describe_image(llm_client, model_name, ref, question),
        )

        # Optional bounded ReAct exploration: gathers evidence and may propose
        # an early ANSWER. Never the only path: a missing or format-failed
        # answer falls through to the normal solve.
        react_early_answer = ""
        react_budget_s = (
            float(strategy.react_time_budget(_solve_budget_s()))
            if getattr(strategy, "react_explore_enabled", False) and hasattr(strategy, "react_time_budget")
            else 0.0
        )
        if react_budget_s > 0:
            react_evidence, react_early_answer = await _react_explore_loop(
                mcp_client=mcp_client,
                llm_client=llm_client,
                model_name=model_name,
                tool_defs=tool_defs,
                called=explored_called,
                agent_id=agent_id,
                challenge_text=str(challenge.description or ""),
                rules=str(challenge.rules or ""),
                clues=clues,
                prior_evidence=tool_evidence_lines,
                budget_s=react_budget_s,
                max_steps=int(getattr(strategy, "react_max_steps", 4)),
                step_timeout_s=float(getattr(strategy, "react_step_timeout_s", 8.0)),
                http_client=http_client,
                stateful_unlock_enabled=stateful_unlock,
            )
            tool_evidence_lines += react_evidence

        prompt_evidence = _payload_evidence(dict(challenge.raw_data)) + tool_evidence_lines

        # Broadcast thought
        http_client.broadcast_thought(agent_id, f"Analyzing {len(clues)} clues...")

        # Save draft (backup)
        http_client.save_draft(agent_id, "Working on solution...")

        rules_blob = f"{challenge.description} {challenge.rules}"
        react_gated = ""
        if react_early_answer:
            react_gated = normalize_answer(react_early_answer, rules_blob)
            if not (react_gated and format_ok(react_gated, rules_blob)):
                react_gated = ""
                print("   🧭 ReAct answer failed format gate; falling back to pipeline solve")

        solve_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            description=challenge.description,
            rules=challenge.rules,
            clues=clues,
            max_time_s=challenge.max_time_s,
            available_models=ranked_models,
            difficulty=challenge_difficulty,
            required_tools=declared_required,
        )
        # ChallengeContext has no evidence field; strategies read it with getattr.
        solve_ctx.evidence = prompt_evidence

        if react_gated:
            # The format gate and verify pass below still run on this answer.
            answer = react_gated
            raw_response = f"ANSWER: {react_gated}"
            usage = {"finish_reason": "react_explore", "prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
            ttft_ms = total_time_ms = 0
            print(f"   🧭 Using ReAct answer (pipeline kept as format/verify fallback): {answer[:120]}")
            http_client.broadcast_thought(agent_id, "Using ReAct explore answer; verifying next...")
        else:
            # Step 3: Solve
            print("\n🧠 Solving...")
            http_client.broadcast_thought(agent_id, "Calling LLM...")

            def _timed_out(model: str):
                usage = {"finish_reason": "timeout", "prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0}
                return "", "", model, usage, 0, 0

            ticker = ReasoningTicker(model_name)

            async def _solve_once(solve_model: str):
                nonlocal ticker
                ticker = ReasoningTicker(solve_model)
                return await _solve_within(
                    _solve_budget_s(),
                    lambda: solve_challenge(
                        challenge,
                        clues,
                        llm_client,
                        solve_model,
                        strategy,
                        solve_ctx,
                        http_client=http_client,
                        agent_id=agent_id,
                        broadcast_thought=True,
                        evidence_lines=tool_evidence_lines,
                        ticker=ticker,
                    ),
                    _timed_out(solve_model),
                )

            # Fail over down the ranking when the proxy errors (model down, 429,
            # 5xx); the stock runtime only retried after a token-limit stop.
            failover_models = [model_name] + [m for m in ranked_models if m != model_name]
            result = await _solve_once(model_name)
            for next_model in failover_models[1:3]:
                if result[3].get("finish_reason") != "error" or _solve_budget_s() < 5:
                    break
                print(f"   🔁 Failing over to {next_model}")
                http_client.broadcast_thought(agent_id, f"Model error; failing over to {next_model}...")
                result = await _solve_once(next_model)
            answer, raw_response, model_name, usage, ttft_ms, total_time_ms = result
            ticker.finish()
            async def _remaining_s() -> float:
                info = await mcp_client.time_remaining(agent_id)
                return float(info.get("time_remaining_s", 0.0))

            async def _solve_with(retry_model: str):
                http_client.broadcast_thought(agent_id, f"Retrying with {retry_model}...")
                return await _solve_once(retry_model)

            answer, raw_response, model_name, usage, ttft_ms, total_time_ms = await _retry_after_length_stop(
                (answer, raw_response, model_name, usage, ttft_ms, total_time_ms),
                ranked_models=ranked_models,
                remaining_s=_remaining_s,
                solve_with=_solve_with,
            )
            ticker.finish()
            for line in summary_lines(
                model=model_name,
                elapsed_s=total_time_ms / 1000,
                usage=usage,
                finish_reason=str(usage.get("finish_reason") or ""),
                answer=answer,
                ticker=ticker,
            ):
                print(line)

            if _is_invalid_answer_candidate(answer):
                answer = ""
            if not answer:
                print("   ⚠️  No valid ANSWER format found; using last line as fallback.")
                lines = raw_response.strip().splitlines()
                last_line = lines[-1].strip().strip("`\"'") if lines else ""
                answer = (
                    last_line
                    if last_line and len(last_line) < 400 and not _is_invalid_answer_candidate(last_line)
                    else "unknown"
                )

        # Format gate before verification / submit.
        answer = normalize_answer(answer, rules_blob)
        if answer and not format_ok(answer, rules_blob):
            print("   ⚠️  Answer failed format gate; trying evidence salvage / cleanup.")
            salvaged = ""
            if tool_evidence_lines:
                salvaged = _derive_answer_from_evidence(
                    llm_client=llm_client,
                    model_name=model_name,
                    challenge_description=str(challenge.description or ""),
                    challenge_rules=str(challenge.rules or ""),
                    evidence_lines=tool_evidence_lines,
                    max_tokens=2048,
                )
            salvaged = normalize_answer(salvaged, rules_blob)
            if salvaged and format_ok(salvaged, rules_blob):
                answer = salvaged

        # Time-boxed second-pass verification for logic/math/riddle.
        verify_floor = float(getattr(strategy, "verify_min_remaining_s", 25.0))
        if (
            answer
            and format_ok(answer, rules_blob)
            and getattr(strategy, "needs_verification", lambda _ctx: False)(solve_ctx)
            and _solve_budget_s() >= verify_floor
        ):
            verify_model = strategy.pick_model("verify", ranked_models, solve_ctx) or model_name
            verify_budget = min(20.0, max(5.0, _solve_budget_s() - submit_reserve_s))
            print(f"   🔍 Verifying with {verify_model} ({verify_budget:.0f}s)...")
            http_client.broadcast_thought(agent_id, f"Verifying candidate with {verify_model}...")
            try:
                verify_response = await asyncio.wait_for(
                    asyncio.to_thread(
                        lambda: llm_client.with_options(timeout=verify_budget, max_retries=0).chat.completions.create(
                            model=verify_model,
                            messages=[
                                {
                                    "role": "system",
                                    "content": (
                                        "You are a strict answer checker. "
                                        "Reply with OK or ANSWER: <corrected> only."
                                    ),
                                },
                                {
                                    "role": "user",
                                    "content": strategy.build_verify_prompt(solve_ctx, answer),
                                },
                            ],
                            max_tokens=1024,
                            temperature=0.0,
                        )
                    ),
                    timeout=verify_budget + 1.0,
                )
                verify_raw = (verify_response.choices[0].message.content or "").strip()
                accepted, corrected = parse_verify_response(verify_raw)
                if not accepted and corrected:
                    corrected = normalize_answer(corrected, rules_blob)
                    if format_ok(corrected, rules_blob):
                        print(f"   ✅ Verifier replaced answer → {corrected[:120]}")
                        http_client.broadcast_thought(agent_id, f"Verifier corrected answer: {corrected[:200]}")
                        answer = corrected
                    else:
                        print("   (verifier correction failed format gate; keeping original)")
                else:
                    print("   ✅ Verifier accepted candidate")
            except Exception as exc:
                print(f"   (verification skipped: {type(exc).__name__})")

        # Save draft with extracted answer as backup
        http_client.save_draft(agent_id, answer, "LLM solution")
        http_client.broadcast_thought(agent_id, f"Answer: {answer}")
        
        # Check time remaining
        time_info = await mcp_client.time_remaining(agent_id)
        remaining_s = float(time_info.get("time_remaining_s", 0.0))
        submit_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            description=challenge.description,
            rules=challenge.rules,
            clues=clues,
            max_time_s=challenge.max_time_s,
            available_models=ranked_models,
            time_remaining_s=remaining_s,
            tokens_used=usage.get("total_tokens", 0),
            difficulty=challenge_difficulty,
            required_tools=declared_required,
        )
        submit_ctx.evidence = prompt_evidence
        if strategy.should_submit_early(answer, submit_ctx):
            http_client.broadcast_thought(agent_id, "⚡ Strategy submitting early.")
        revised_answer = strategy.on_time_warning(remaining_s, answer, submit_ctx)
        if isinstance(revised_answer, str) and revised_answer.strip():
            answer = revised_answer.strip()
        # Final format gate: never submit broken JSON / empty shells when we have a fallback.
        gated = strategy.gate_answer(answer, submit_ctx) if hasattr(strategy, "gate_answer") else answer
        if gated:
            answer = gated
        elif not format_ok(answer, rules_blob):
            answer = strategy.fallback_answer(submit_ctx)
        print(f"   Time remaining: {time_info['time_remaining_s']:.1f}s")
    
    # Step 4: Submit the extracted answer with real metrics
    print("\n📤 Submitting answer...")
    http_client.broadcast_thought(agent_id, "Submitting final answer!")
    await _stop_metrics_reporter()
    http_client.flush()
    
    result = http_client.submit(
        agent_id=agent_id,
        answer=answer,
        client_metrics={
            "model_name": model_name,
            "total_tokens": str(live_total_tokens),
            "prompt_tokens": str(live_prompt_tokens),
            "completion_tokens": str(live_completion_tokens),
            "ttft_ms": ttft_ms,
            "total_time_ms": total_time_ms,
        }
    )
    
    print(f"   Accepted: {result.accepted}")
    print(f"   Status: {result.status}")
    if result.score:
        print(f"   Score: {result.score.get('final_score', 0)}")
        print(f"   Quality: {result.score.get('quality_score', 0)}")
        print(f"   Speed: {result.score.get('speed_score', 0)}")
    if missing_tools_note(result):
        print(f"   ⚠️  {missing_tools_note(result)}")
    
    await session_monitor.stop()
    # Last step, after the submission is final; never raises.
    run_record = {
        "agent_id": agent_id,
        "challenge": challenge_record(challenge),
        "model": model_name,
        "answer": answer,
        "usage": usage,
        "total_time_ms": total_time_ms,
        "result": {
            "accepted": result.accepted,
            "status": result.status,
            "score": result.score,
        },
    }
    print(f"   Run record: {save_run_record(agent_id, run_record, REPO_ROOT)}")
    _append_run_log(agent_id, run_record)
    print("\n✅ Agent completed!")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except asyncio.CancelledError:
        raise SystemExit(0)
    except ModelSelectionError as exc:
        print(f"   {exc}")
        raise SystemExit(1)
