"""ATOM: adaptive-skill strategy for Agent Gauntlet.

Each challenge is classified with cheap keyword rules (no LLM call) into a
skill. A skill profile carries its own prompt, model preferences, sampling
settings, token budget and a deterministic fallback answer. Everything is
wired through the hooks the bundled runtime actually calls; ``plan_tools``
and ``on_tool_result`` are deliberately left alone.

Profiles were tuned on Practice runs and are frozen for the event: nothing
here learns at runtime, because only the first submit counts.
"""

from __future__ import annotations

import base64
import binascii
import json
import re
from collections import Counter
from dataclasses import dataclass
from typing import Any
from urllib.parse import unquote_plus

from base_strategy import BaseStrategy, ChallengeContext


# --- Deterministic pre-processing skills (no LLM calls, stdlib only) ---------
# Black-box challenges hide data in encodings, logs and long tool outputs;
# these run in plain Python before the model sees the prompt.

# Small English vocabulary for scoring decoded candidates.
_COMMON_WORDS = frozenset(
    """
    the be to of and a in that have i it for not on with he as you do at this but his by from they we say her she
    or an will my one all would there their what so up out if about who get which go me when make can like time no
    just him know take people into year your good some could them see other than then now look only come its over
    think also back after use two how our work first well way even new want because any these give day most us is
    are was were been has had did said find here thing many where why key secret code answer word hidden message
    flag password open door left right north south east west red blue green black white gold city name number
    meet at noon night morning tomorrow today treasure under behind box room final clue next step call tool use
    """.split()
)

_MORSE = {
    ".-": "A", "-...": "B", "-.-.": "C", "-..": "D", ".": "E", "..-.": "F", "--.": "G", "....": "H", "..": "I",
    ".---": "J", "-.-": "K", ".-..": "L", "--": "M", "-.": "N", "---": "O", ".--.": "P", "--.-": "Q", ".-.": "R",
    "...": "S", "-": "T", "..-": "U", "...-": "V", ".--": "W", "-..-": "X", "-.--": "Y", "--..": "Z",
    "-----": "0", ".----": "1", "..---": "2", "...--": "3", "....-": "4", ".....": "5", "-....": "6",
    "--...": "7", "---..": "8", "----.": "9",
}

_B64_TOKEN = re.compile(r"[A-Za-z0-9+/_-]{12,}={0,2}")
_HEX_TOKEN = re.compile(r"\b(?:0x)?((?:[0-9a-fA-F]{2}[\s:]?){6,})\b")
_BIN_TOKEN = re.compile(r"\b(?:[01]{8}\s*){3,}")
_MORSE_TOKEN = re.compile(r"(?:[.\-]{1,6}[ /]+){2,}[.\-]{1,6}")
# Bounds the work on large tool dumps (each XOR or Caesar try is cheap, not free).
_MAX_TOKENS = 30
_MAX_SEGMENTS = 200
_PERCENT_TOKEN =re.compile(r"(?:%[0-9A-Fa-f]{2}|[\w.\-+]){6,}")


def english_score(text: str) -> float:
    """Share of non-space characters that belong to common English words (0..1).

    Weighting by characters, not words, keeps stray one-letter "words" in
    XOR or Caesar junk (``=!,i?(<``) from scoring as English.
    """
    chars = sum(not ch.isspace() for ch in text)
    if not chars:
        return 0.0
    words = re.findall(r"[a-zA-Z]+", text.lower())
    return sum(len(word) for word in words if word in _COMMON_WORDS) / chars


def _printable(data: bytes) -> str | None:
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        return None
    if not text or sum(ch.isprintable() or ch in "\n\t" for ch in text) / len(text) < 0.95:
        return None
    return text


def _best_xor(data: bytes) -> tuple[int, str] | None:
    best: tuple[float, int, str] | None = None
    for key in range(1, 256):
        text = _printable(bytes(b ^ key for b in data))
        if text:
            score = english_score(text)
            if score >= 0.5 and (best is None or score > best[0]):
                best = (score, key, text)
    return (best[1], best[2]) if best else None


def _bytes_candidates(label: str, data: bytes) -> list[tuple[str, str]]:
    text = _printable(data)
    if text and english_score(text) >= 0.3:
        return [(label, text)]
    # Printable gibberish can still be single-byte XOR ciphertext.
    xored = _best_xor(data)
    if xored:
        return [(f"{label} + xor 0x{xored[0]:02x}", xored[1])]
    return [(label, text)] if text else []


def _caesar(text: str, shift: int) -> str:
    out = []
    for ch in text:
        if "a" <= ch <= "z":
            out.append(chr((ord(ch) - 97 + shift) % 26 + 97))
        elif "A" <= ch <= "Z":
            out.append(chr((ord(ch) - 65 + shift) % 26 + 65))
        else:
            out.append(ch)
    return "".join(out)


def decode_candidates(text: str, *, limit: int = 8) -> list[tuple[str, str]]:
    """Plausible decodings found in ``text`` as (method, decoded) pairs.

    Only results that read as text (printable, and English-like for the
    letter ciphers) are kept, so plain prose yields nothing.
    """
    found: list[tuple[str, str]] = []
    seen: set[str] = set()

    def add(label: str, decoded: str, source: str) -> None:
        decoded = decoded.strip()
        if decoded and decoded not in seen and decoded.lower() != source.strip().lower():
            seen.add(decoded)
            found.append((f"{label} of '{source[:40]}'", decoded[:500]))

    for token in _B64_TOKEN.findall(text)[:_MAX_TOKENS]:
        if re.fullmatch(r"[A-Za-z]+", token) and english_score(token) > 0:
            continue
        padded = token + "=" * (-len(token) % 4)
        for label, decoder in (("base64", base64.b64decode), ("base64url", base64.urlsafe_b64decode)):
            try:
                data = decoder(padded)
            except (binascii.Error, ValueError):
                continue
            for method, decoded in _bytes_candidates(label, data):
                add(method, decoded, token)
            break
    for match in list(_HEX_TOKEN.finditer(text))[:_MAX_TOKENS]:
        raw = re.sub(r"[\s:]", "", match.group(1))
        if len(raw) % 2 == 0 and re.search(r"[a-fA-F]", raw) or len(raw) >= 16:
            try:
                for method, decoded in _bytes_candidates("hex", bytes.fromhex(raw)):
                    add(method, decoded, match.group(0))
            except ValueError:
                pass
    for match in list(_BIN_TOKEN.finditer(text))[:_MAX_TOKENS]:
        bits = re.findall(r"[01]{8}", match.group(0))
        for method, decoded in _bytes_candidates("binary", bytes(int(b, 2) for b in bits)):
            add(method, decoded, match.group(0))
    for match in list(_MORSE_TOKEN.finditer(text))[:_MAX_TOKENS]:
        words = re.split(r"\s*/\s*|\s{3,}", match.group(0).strip())
        decoded = " ".join("".join(_MORSE.get(sym, "?") for sym in word.split()) for word in words)
        if decoded.count("?") <= len(decoded) // 5:
            add("morse", decoded, match.group(0))
    if "%" in text:
        for token in _PERCENT_TOKEN.findall(text)[:_MAX_TOKENS]:
            if "%" in token:
                add("url-decode", unquote_plus(token), token)

    # Letter ciphers: only for segments that do not already read as English.
    for segment in re.split(r"[\n\"“”]+", text)[:_MAX_SEGMENTS]:
        letters = sum(ch.isalpha() for ch in segment)
        if letters < 8 or english_score(segment) >= 0.3:
            continue
        shifts = [(english_score(_caesar(segment, s)), s) for s in range(1, 26)]
        score, shift = max(shifts)
        if score >= 0.4:
            add("rot13" if shift == 13 else f"caesar shift +{shift}", _caesar(segment, shift), segment)
        reversed_segment = segment[::-1]
        if english_score(reversed_segment) >= 0.4:
            add("reversed", reversed_segment, segment)
        atbash = segment.translate(str.maketrans(
            "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ",
            "zyxwvutsrqponmlkjihgfedcbaZYXWVUTSRQPONMLKJIHGFEDCBA",
        ))
        if english_score(atbash) >= 0.4:
            add("atbash", atbash, segment)
    return found[:limit]


_LOG_LINE = re.compile(
    r"(?:\d{4}-\d{2}-\d{2}|\d{2}:\d{2}:\d{2}|\b(?:INFO|WARN(?:ING)?|ERROR|DEBUG|CRITICAL|FATAL|TRACE)\b)"
)
_LEVEL = re.compile(r"\b(INFO|WARN(?:ING)?|ERROR|DEBUG|CRITICAL|FATAL|TRACE)\b")
_TIME = re.compile(r"(\d{2}):(\d{2}):(\d{2})")
_IP = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}\b")
_USER = re.compile(r"\b(?:user|uid|account|login)[=: ]+([\w.@-]+)", re.I)


def _template(line: str) -> str:
    line = _IP.sub("<ip>", line)
    line = re.sub(r"\b[0-9a-f]{8,}\b", "<hex>", line, flags=re.I)
    return re.sub(r"\d+", "<n>", line)


def log_triage(text: str, *, max_lines: int = 40) -> str:
    """Summarise log-like text and pick out the suspicious lines.

    Returns "" when fewer than 8 lines look like log records.
    """
    lines = [line for line in text.splitlines() if line.strip()]
    records = [line for line in lines if _LOG_LINE.search(line)]
    if len(records) < 8 or len(records) < len(lines) * 0.5:
        return ""
    levels = Counter(m.group(1).upper() for line in records if (m := _LEVEL.search(line)))
    templates = Counter(_template(line) for line in records)
    flagged: dict[str, str] = {}
    for line in records:
        level = _LEVEL.search(line)
        if level and level.group(1).upper() in {"ERROR", "CRITICAL", "FATAL", "WARN", "WARNING"}:
            flagged.setdefault(line, "level")
    for line in records:
        if templates[_template(line)] == 1:
            flagged.setdefault(line, "rare template")
    for pattern, label in ((_IP, "rare ip"), (_USER, "rare user")):
        counts = Counter(v for line in records for v in pattern.findall(line))
        if len(counts) >= 3:
            for line in records:
                if any(counts[v] == 1 for v in pattern.findall(line)):
                    flagged.setdefault(line, label)
    gaps = []
    previous = None
    for line in records:
        match = _TIME.search(line)
        if not match:
            continue
        seconds = int(match.group(1)) * 3600 + int(match.group(2)) * 60 + int(match.group(3))
        if previous is not None and seconds - previous[0] > 0:
            gaps.append((seconds - previous[0], previous[1], line))
        previous = (seconds, line)
    summary = [
        f"{len(records)} log records, {len(templates)} distinct templates; levels: "
        + ", ".join(f"{k}={v}" for k, v in levels.most_common()),
    ]
    if gaps:
        gaps.sort(reverse=True)
        median = sorted(g[0] for g in gaps)[len(gaps) // 2]
        if gaps[0][0] > max(5 * median, 60):
            summary.append(f"largest time gap {gaps[0][0]}s (median {median}s) before: {gaps[0][2].strip()[:200]}")
    if flagged:
        summary.append("Suspicious lines (reason):")
        for line, reason in list(flagged.items())[:max_lines]:
            summary.append(f"- [{reason}] {line.strip()[:300]}")
    return "\n".join(summary)


_JSON_SPAN = re.compile(r"(\{.*\}|\[.*\])", re.S)


def normalize_answer(answer: str, rules: str) -> str:
    """Deterministic format clean-up of a final answer; never invents content."""
    text = str(answer or "").strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in "`\"'":
        text = text[1:-1].strip()
    text = re.sub(r"^```\w*\s*|\s*```$", "", text).strip()
    lowered = rules.lower()
    if "json" in lowered:
        match = _JSON_SPAN.search(text)
        if match:
            try:
                return json.dumps(json.loads(match.group(1)), separators=(",", ":"), ensure_ascii=False)
            except ValueError:
                pass
        return text
    if re.search(r"comma[- ]separated", lowered) and "\n" not in text and "," in text:
        if not re.search(r"no spaces?|without spaces?", lowered):
            text = ", ".join(part.strip() for part in text.split(","))
    return text


def is_valid_json(text: str) -> bool:
    try:
        json.loads(text)
    except ValueError:
        return False
    return True


# --- Skill profiles ---------------------------------------------------------

@dataclass(frozen=True)
class SkillProfile:
    name: str
    # Substrings matched against live /models ids, best first. The event
    # roster differs from Practice, so these are preferences, not requirements.
    fast_models: tuple[str, ...]
    strong_models: tuple[str, ...]
    temperature: float
    # Completion budget per difficulty; reasoning models need headroom.
    budgets: tuple[tuple[str, int], ...]
    system: str
    method: str
    fallback: str = ""
    # Write a short checked working before the ANSWER line.
    worked: bool = False


# Practice bench (3 logic puzzles x 3 trials, ATOM prompts): gpt-5.6-terra 9/9
# at ~3 s / ~450 tokens; nemotron-3-super and gemini-3.6-flash 9/9 at 16-18 s;
# gpt-5.4 8/9 at 1.5 s; lightning/ultra/qwen3.7-max 6/9 (ran out of tokens).
# atom_bench (13 puzzles, all skills): gpt-5.6-terra 13/13 2.4 s; gemini-3.6-flash
# 13/13 3.5 s; nemotron-3-super 13/13 6.1 s; lightning 12/13.
_TEXT_FAST = ("gpt-5.6", "gemini-3.6-flash", "nemotron-3-super", "gpt-5.4")
_TEXT_STRONG = ("gpt-5.6", "gemini-3.6-flash", "nemotron-3-super", "gpt-5.4")
# Fast models stop early, so a large ceiling costs nothing; it only protects
# a reasoning-model fallback from ending mid-thought with no answer.
_BUDGETS = (("easy", 8192), ("medium", 12288), ("hard", 16384))

_ANSWER_RULES = (
    "- The final answer must match the format the challenge asks for exactly "
    "(order, separators, capitalisation, units, names spelled as given).\n"
    "- For lists, unless the rules show another separator, separate items with a comma and a space.\n"
    "- Answer with only the value asked for: after decoding or reading evidence, drop labels "
    "such as PASSWORD, KEY, CODE: or 'the answer is'.\n"
    "- No markdown, quotes, code fences or <think> tags.\n"
    "- Never answer 'unknown'; commit to the best-supported answer."
)
_FORMAT_DIRECT = "Output format (strict):\n- Reply with exactly one line: ANSWER: <final answer>\n" + _ANSWER_RULES
# Answering before checking cost gpt-5.6-terra 2 of 18 logic puzzles on
# Practice; a few lines of explicit checking before the answer fixed that.
_FORMAT_WORKED = (
    "Output format (strict):\n"
    "- First a compact working of at most 12 short lines: the candidate solution, "
    "then each clue checked against it (fix and re-check on any failure). "
    "No working line may start with 'Answer'.\n"
    "- Then one final line: ANSWER: <final answer>\n" + _ANSWER_RULES
)

_LOGIC = SkillProfile(
    name="logic",
    worked=True,
    fast_models=_TEXT_FAST,
    strong_models=_TEXT_STRONG,
    temperature=0.0,
    budgets=_BUDGETS,
    system=(
        "You are ATOM, a precise solver of deduction and constraint puzzles. "
        "You check every clue against your solution before committing to it."
    ),
    method=(
        "Method: list the entities, translate each clue into a constraint, "
        "eliminate impossibilities, then verify the full solution satisfies "
        "EVERY clue before answering. Use only the names given in the challenge."
    ),
)

_MATH = SkillProfile(
    name="math",
    worked=True,
    fast_models=_TEXT_FAST,
    strong_models=_TEXT_STRONG,
    temperature=0.0,
    budgets=_BUDGETS,
    system=(
        "You are ATOM, a careful quantitative solver. You compute exactly "
        "and double-check the arithmetic before committing."
    ),
    method=(
        "Method: identify the quantities, compute step by step, re-check the "
        "arithmetic, and give the result with the units or precision requested."
    ),
)

_RETRIEVAL = SkillProfile(
    name="retrieval",
    fast_models=_TEXT_FAST,
    strong_models=_TEXT_STRONG,
    temperature=0.0,
    budgets=_BUDGETS,
    system=(
        "You are ATOM, a retrieval specialist. You answer strictly from the "
        "clues and tool evidence provided, quoting names and values exactly."
    ),
    method=(
        "Method: find the clue or evidence lines that answer the question, "
        "combine them if needed, and copy names, numbers and dates verbatim."
    ),
)

_STRUCTURED = SkillProfile(
    name="structured",
    fast_models=_TEXT_FAST,
    strong_models=_TEXT_STRONG,
    temperature=0.0,
    budgets=_BUDGETS,
    system=(
        "You are ATOM, a structured-output specialist. Your answer is "
        "machine-checked, so it must be valid and match the requested schema exactly."
    ),
    method=(
        "Method: work out the content, then emit it on the ANSWER line in the "
        "exact structure requested (compact single-line JSON when JSON is asked, "
        "double quotes, no trailing commas, keys exactly as specified)."
    ),
)

_RIDDLE = SkillProfile(
    name="riddle",
    worked=True,
    fast_models=_TEXT_FAST,
    strong_models=_TEXT_STRONG,
    temperature=0.0,
    budgets=_BUDGETS,
    system=(
        "You are ATOM, a solver of riddles, ciphers and wordplay. You consider "
        "several readings before committing to the one every clue supports."
    ),
    method=(
        "Method: use any decoded candidates below first. List 2-3 candidate readings "
        "(literal, pun, anagram, hidden word, first letters, cipher), check each against "
        "EVERY clue, then commit to the one that fits all of them."
    ),
)

_LOGS = SkillProfile(
    name="logs",
    worked=True,
    fast_models=_TEXT_FAST,
    strong_models=_TEXT_STRONG,
    temperature=0.0,
    budgets=_BUDGETS,
    system=(
        "You are ATOM, an incident analyst. You find the anomalous events in "
        "logs and data and cite them exactly as they appear."
    ),
    method=(
        "Method: start from the pre-computed log triage, confirm each suspicious line "
        "against the raw evidence, and answer with identifiers, timestamps or values "
        "copied verbatim."
    ),
)

_GENERAL = SkillProfile(
    name="general",
    fast_models=_TEXT_FAST,
    strong_models=_TEXT_STRONG,
    temperature=0.0,
    budgets=_BUDGETS,
    system=(
        "You are ATOM, a careful problem solver. You follow the challenge rules "
        "exactly and state only the final answer."
    ),
    method="Method: read the rules first, solve, then check the answer against every rule.",
)

# Image skills only choose the planner/image model and the prompt.
# Practice (image judge gpt-5.4, +-5 run to run): edits scored flash-lite 87.3
# avg in ~11 s vs pro 85.4 in ~22 s; generation scored pro 88.7 vs flash-lite 86.4.
_IMAGE_EDIT_MODELS = ("gemini-3.1-flash-lite-image", "gemini-3.1-flash-image", "gemini-3-pro-image")
_IMAGE_GENERATE_MODELS = ("gemini-3-pro-image", "gemini-3.1-flash-image", "gemini-3.1-flash-lite-image")

_TEXT_PROFILES = {p.name: p for p in (_LOGIC, _MATH, _RETRIEVAL, _STRUCTURED, _RIDDLE, _LOGS, _GENERAL)}

# Challenge-type substrings that name a skill outright.
_TYPE_SKILLS = (
    ("logic", "logic"), ("math", "math"), ("retriev", "retrieval"), ("structured", "structured"),
    ("riddle", "riddle"), ("cipher", "riddle"), ("decod", "riddle"), ("wordplay", "riddle"),
    ("log", "logs"), ("anomal", "logs"),
)
# Evidence beyond this is cut so a huge tool dump cannot crowd out the question.
_EVIDENCE_CHAR_LIMIT = 120_000

_STRUCTURED_RULES = re.compile(r"\b(?:json|schema|yaml|csv|exact format|keys? named|fields?:)", re.I)

# Weighted signals; the strongest skill wins. Substring rules sent "summit"
# to math and "border" to logic, so every signal is compiled word-bounded.
# Ties go to the earlier skill (retrieval, then math, then logic).
_SKILL_SIGNALS: tuple[tuple[str, tuple[tuple[str, float], ...]], ...] = (
    ("riddle", (
        (r"riddles?", 3), (r"what am i", 3), (r"anagrams?", 3), (r"ciphers?", 3), (r"encrypt\w*", 2),
        (r"encod\w*", 2), (r"decod\w*", 2), (r"wordplay", 3), (r"puns?", 2), (r"acrostic", 3),
        (r"hidden (?:word|message|meaning)", 3), (r"secret (?:word|message|code)", 2),
    )),
    ("logs", (
        (r"logs?", 2), (r"anomal\w*", 3), (r"outliers?", 2), (r"suspicious", 2), (r"incident", 2),
        (r"intrusion", 2), (r"breach", 2), (r"(?:error|access|server|auth) logs?", 3),
    )),
    ("retrieval", (
        (r"according to", 3), (r"documents?", 2), (r"sources?", 2), (r"reports?", 2),
        (r"passages?", 2), (r"mention(?:s|ed)?", 2), (r"named in", 2), (r"cited", 2),
        (r"listed", 1), (r"look ?up", 2), (r"retriev\w*", 3), (r"search\w*", 2),
        (r"which (?:city|country|town|person|company|year|team|document)", 1),
    )),
    ("math", (
        (r"calculat\w*", 3), (r"compute\w*", 3), (r"sum of", 2), (r"total (?:cost|price|number|of)", 2),
        (r"how many", 1), (r"percent\w*", 2), (r"average", 2), (r"probabilit\w*", 3),
        (r"equations?", 3), (r"remainder", 2), (r"\d+\s*[-+*/x×÷]\s*\d+", 2),
    )),
    ("logic", (
        (r"logic\w*", 3), (r"puzzle", 2), (r"deduc\w*", 3), (r"infer", 2), (r"constraints?", 2),
        (r"(?:the|full|exact|correct|presentation|chronological) order", 3), (r"sequence", 1),
        (r"arrange\w*", 2), (r"seat(?:s|ed|ing)?", 2), (r"sits?", 1), (r"line up", 2),
        (r"who (?:is|owns|sits)", 2), (r"each (?:person|team)", 2), (r"exactly one", 2),
        (r"neither", 1), (r"immediately (?:before|after|to the)", 2), (r"(?:left|right) of", 1),
    )),
)
_SKILL_PATTERNS = tuple(
    (name, tuple((re.compile(rf"\b(?:{pattern})\b", re.I), weight) for pattern, weight in signals))
    for name, signals in _SKILL_SIGNALS
)

_ASKS_FOR_TEXT = re.compile(r"\btext\b|\btitle\b|caption|label|lettering|headline|slogan|\bwords?\b|[\"“].+?[\"”]", re.I)
_FORBIDS_TEXT = re.compile(r"\bno (?:text|words|letters|lettering|captions?)\b|without (?:any )?text|avoid[^.]*text", re.I)

_SIGNAGE_SCENE = re.compile(
    r"\b(?:neon|street|city|shop|store|storefront|billboard|signs?|market|cafe|arcade|poster|cockpit|dashboard|screens?)\b",
    re.I,
)

# Practice time limits map to difficulty (60/90/120 s); used when the runtime
# does not pass difficulty through.
_DIFFICULTY_BY_TIME = ((75, "easy"), (105, "medium"))


class MyStrategy(BaseStrategy):
    """ATOM competitor strategy."""

    agent_id = "atom"
    agent_name = "ATOM"

    text_system_prompt = _GENERAL.system
    text_strategy_notes = "Classify, apply the skill profile, answer on one ANSWER line."
    text_temperature = 0.0
    text_max_tokens = 8192

    image_strategy_notes = (
        "image_edit when an input image exists, otherwise image_generate. "
        "Spell out every constraint; standard resolution only."
    )

    # Appended by the runtime after the solver prompt (patched to read this);
    # the stock "return only your final answer line" contradicts worked skills.
    output_guardrails = (
        "- Nothing after the ANSWER line.\n"
        "- Do not output tool-call markup, XML tags, or <think> traces."
    )

    # Leave this much time for submit after the model answers.
    submit_reserve_s = 8.0

    # --- classification -----------------------------------------------------

    @staticmethod
    def difficulty(ctx: ChallengeContext) -> str:
        level = str(ctx.difficulty or "").strip().lower()
        if level in {"easy", "medium", "hard"}:
            return level
        if ctx.max_time_s:
            for limit, name in _DIFFICULTY_BY_TIME:
                if ctx.max_time_s <= limit:
                    return name
            return "hard"
        return "medium"

    def classify(self, ctx: ChallengeContext) -> str:
        if self.is_image_challenge(ctx):
            return "image-edit" if ctx.image_url or "edit" in ctx.challenge_type.lower() else "image-generate"
        ctype = ctx.challenge_type.lower()
        for marker, name in _TYPE_SKILLS:
            # Word-start match, so "catalog" is not a log task; "logic" is checked before "log".
            if re.search(rf"(?:^|[^a-z]){marker}", ctype):
                return name
        # Rules carry the output format, so they decide "structured" first.
        if _STRUCTURED_RULES.search(ctx.rules or ""):
            return "structured"
        # The question itself counts double; clues and rules once.
        texts = ((ctx.description, 2.0), (ctx.challenge_text, 0.0), (ctx.rules, 1.0), (" ".join(ctx.clues), 1.0))
        best, best_score = "general", 0.0
        for name, patterns in _SKILL_PATTERNS:
            score = sum(
                weight * factor
                for pattern, weight in patterns
                for text, factor in texts
                if factor and text and pattern.search(text)
            )
            if score > best_score:
                best, best_score = name, score
        return best

    def profile(self, ctx: ChallengeContext) -> SkillProfile:
        return _TEXT_PROFILES.get(self.classify(ctx), _GENERAL)

    # --- models -------------------------------------------------------------

    @staticmethod
    def _match(preferences: tuple[str, ...], available: list[str]) -> list[str]:
        ranked: list[str] = []
        for wanted in preferences:
            for model in available:
                if model not in ranked and (model == wanted or model.startswith(wanted)):
                    ranked.append(model)
        return ranked

    @staticmethod
    def _name_score(model: str) -> float:
        """Rough capability score from the alias, for models no profile names."""
        name = model.lower()
        score = 0.0
        for token, weight in (("ultra", 3), ("max", 3), ("pro", 2.5), ("super", 2), ("plus", 2),
                              ("gpt", 2), ("flash", 1), ("lite", -1.5), ("lightning", -1), ("mini", -1),
                              ("nano", -2)):
            if token in name:
                score += weight
        numbers = re.findall(r"\d+(?:\.\d+)?", name)
        if numbers:
            score += min(float(numbers[0]), 10.0) * 0.2
        return score

    def rank_models(self, ctx: ChallengeContext, available_models: list[str]) -> list[str]:
        available = [m for m in available_models if str(m).strip()]
        if self.is_image_challenge(ctx):
            image_models = self.prefer_image_models(available) or [
                m for m in available if "image" in m.lower()
            ]
            prefs = _IMAGE_EDIT_MODELS if self.classify(ctx) == "image-edit" else _IMAGE_GENERATE_MODELS
            preferred = self._match(prefs, image_models)
            rest = sorted((m for m in image_models if m not in preferred), key=self._name_score, reverse=True)
            return preferred + rest or available

        text_models = [m for m in available if "image" not in m.lower()] or available
        profile = self.profile(ctx)
        prefs = profile.fast_models if self.difficulty(ctx) == "easy" else profile.strong_models
        preferred = self._match(prefs, text_models)
        rest = sorted((m for m in text_models if m not in preferred), key=self._name_score, reverse=True)
        return preferred + rest

    def probe_models(self, available_models: list[str]) -> list[str]:
        """Text models the patched runtime health-checks before the challenge starts."""
        text_models = [m for m in available_models if "image" not in m.lower()]
        targets = self._match(_TEXT_FAST + _TEXT_STRONG, text_models)
        if len(targets) < 2:
            targets += sorted((m for m in text_models if m not in targets), key=self._name_score, reverse=True)
        return targets[:4]

    def pick_model(self, stage: str, ranked_models: list[str], ctx: ChallengeContext) -> str:
        _ = stage, ctx
        return ranked_models[0] if ranked_models else ""

    # --- text prompts -------------------------------------------------------

    def build_system_prompt(self, ctx: ChallengeContext) -> str:
        profile = self.profile(ctx)
        return f"{profile.system}\n\n{_FORMAT_WORKED if profile.worked else _FORMAT_DIRECT}"

    def build_solver_prompt(self, ctx: ChallengeContext) -> str:
        profile = self.profile(ctx)
        clues = "\n".join(f"{i}. {c.strip()}" for i, c in enumerate(ctx.clues, 1) if c.strip())
        parts = [
            f"Challenge ({ctx.challenge_type or 'text'}): {ctx.description.strip() or 'n/a'}",
            f"Required answer format: {ctx.rules.strip() or 'a single concise answer'}",
        ]
        if clues:
            parts.append(f"Clues:\n{clues}")
        evidence = self._evidence_block(ctx)
        if evidence:
            parts.append(f"Evidence from challenge tools and payload:\n{evidence}")
        prepared = self._prepared_findings(ctx)
        if prepared:
            parts.append(prepared)
        parts.append(profile.method)
        parts.append(
            "Finish with the line: ANSWER: <answer in the required format>"
            if profile.worked
            else "Reply with exactly one line: ANSWER: <answer in the required format>"
        )
        return "\n\n".join(parts)

    @staticmethod
    def _evidence(ctx: ChallengeContext) -> list[str]:
        """Tool results and extra payload fields the patched runtime attaches."""
        return [str(line) for line in getattr(ctx, "evidence", None) or [] if str(line).strip()]

    def _evidence_block(self, ctx: ChallengeContext) -> str:
        block, used = [], 0
        for line in self._evidence(ctx):
            if used + len(line) > _EVIDENCE_CHAR_LIMIT:
                block.append(f"[... {len(self._evidence(ctx)) - len(block)} more evidence item(s) truncated]")
                break
            block.append(f"- {line}")
            used += len(line)
        return "\n".join(block)

    def _prepared_findings(self, ctx: ChallengeContext) -> str:
        """Deterministic decodes and log triage, computed in code before the model runs."""
        sources = [ctx.description, ctx.rules, *ctx.clues, *self._evidence(ctx)]
        sections = []
        decoded = []
        for text in sources:
            decoded.extend(decode_candidates(str(text or ""), limit=4))
        if decoded:
            lines = "\n".join(f"- {method}: {value}" for method, value in decoded[:12])
            sections.append(f"Decoded candidates (computed, may be decoys; verify against the clues):\n{lines}")
        triage = log_triage("\n".join(str(text or "") for text in sources))
        if triage:
            sections.append(f"Log triage (computed):\n{triage}")
        return "\n\n".join(sections)

    def get_llm_params(self, ctx: ChallengeContext) -> dict[str, Any]:
        profile = self.profile(ctx)
        budgets = dict(profile.budgets)
        max_tokens = budgets.get(self.difficulty(ctx), self.text_max_tokens)
        return {"temperature": profile.temperature, "max_tokens": int(max_tokens)}

    # --- deadline -----------------------------------------------------------

    @staticmethod
    def _valid(answer: str) -> bool:
        text = str(answer or "").strip()
        return bool(text) and text.lower() not in {"unknown", "n/a", "none"} and "<" not in text[:1]

    def fallback_answer(self, ctx: ChallengeContext) -> str:
        """Deterministic, format-shaped guess when the model gave nothing."""
        profile = self.profile(ctx)
        if profile.fallback:
            return profile.fallback
        rules = f"{ctx.description} {ctx.rules}".lower()
        if profile.name == "structured" or "json" in rules:
            return "{}"
        if "comma-separated" in rules or "order" in rules:
            names = self._capitalised_names(" ".join(ctx.clues))
            if names:
                return ", ".join(names)
        if profile.name == "math" or re.search(r"\bnumber\b|how many", rules):
            return "0"
        return "No answer"

    @staticmethod
    def _capitalised_names(text: str) -> list[str]:
        stop = {"The", "A", "An", "If", "Each", "No", "Team", "Teams", "One", "Neither", "Either",
                "Exactly", "Both", "Who", "Which", "Then", "After", "Before", "Not"}
        seen: list[str] = []
        for word in re.findall(r"\b[A-Z][a-zA-Z]+\b", text):
            if word not in stop and word not in seen:
                seen.append(word)
        return seen

    def should_submit_early(self, answer: str, ctx: ChallengeContext) -> bool:
        # A valid answer is submitted straight away: speed is scored and a
        # second model pass rarely changes a checked logic answer.
        return self._valid(answer) or ctx.time_remaining_s <= self.submit_reserve_s

    def on_time_warning(self, remaining_s: float, current_answer: str, ctx: ChallengeContext) -> str | None:
        _ = remaining_s
        # Deterministic self-check: tidy quotes/fences, compact JSON, list
        # separators; an answer that still fails its format falls back.
        rules = f"{ctx.description} {ctx.rules}"
        answer = normalize_answer(current_answer, rules)
        if self._valid(answer) and ("json" not in rules.lower() or is_valid_json(answer)):
            return answer
        if self._valid(current_answer):
            return current_answer.strip()
        return self.fallback_answer(ctx)

    # --- images -------------------------------------------------------------

    def plan_image_tool(self, ctx: ChallengeContext, available_tools: list[str]) -> str:
        # No image_analyze pre-pass: tool coverage was already 100 without it,
        # and on Practice it cost ~15 speed points with no preservation gain.
        if ctx.image_url and "image_edit" in available_tools:
            return "image_edit"
        if "image_generate" in available_tools:
            return "image_generate"
        return super().plan_image_tool(ctx, available_tools)

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        instruction = ctx.rules.strip() or ctx.challenge_text.strip() or ctx.description.strip()
        context = ctx.description.strip()
        # The generate judge scores constraints separately; "no text" was the
        # weakest axis on Practice (constraints 44-60 vs quality ~90).
        wants_text = _ASKS_FOR_TEXT.search(instruction) and not _FORBIDS_TEXT.search(instruction)
        constraints = [
            "Render any requested text exactly as quoted, legibly, and no other text."
            if wants_text
            else "Absolutely no text, letters, numbers, captions, signage, logos or watermarks anywhere in the image.",
            "Honour every constraint in the instruction literally.",
            "Single coherent scene, clean composition, sharp focus; use the style the instruction names, "
            "otherwise photorealistic.",
            "Standard resolution only (about 1024 px on the longest side); no HD, 4K or upscaling.",
        ]
        if self.classify(ctx) == "image-edit":
            # Every extra edit instruction we tried lowered judged preservation
            # on Practice (long list ~62, short reminder ~64 vs stock ~73), so
            # edits use the kit's own prompt.
            return super().build_image_prompt(ctx)
        lines = [instruction]
        if not wants_text and self.classify(ctx) == "image-generate":
            # A trailing rule was not enough: a "rainy neon street, no text"
            # baseline image was covered in readable shop signs (constraints 44).
            lines.insert(0, "Hard rule: the image must contain no readable text, letters or numbers of any kind.")
            if _SIGNAGE_SCENE.search(f"{instruction} {context}"):
                constraints.insert(
                    1,
                    "All signs, billboards, screens and storefronts are blank glowing shapes or abstract "
                    "light patterns with no letters, numbers or symbols in any script.",
                )
        if context and context not in instruction:
            lines.append(f"Purpose: {context}")
        lines.append("Requirements:\n" + "\n".join(f"- {c}" for c in constraints))
        return "\n\n".join(lines)
